"""Plain native test UI. Visual polish intentionally deferred."""
import json
import sys
import threading
import time
import win32gui
from pathlib import Path
from PySide6.QtCore import QObject, Signal, Qt, QTimer,QSize
from PySide6.QtGui import QImage, QPixmap, QIcon
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QFormLayout, QPushButton, QLabel, QComboBox, QTabWidget, QPlainTextEdit, QLineEdit,
    QDoubleSpinBox, QSpinBox, QCheckBox, QListWidget, QListWidgetItem, QSplitter,QScrollArea,QDialog,QTableWidget,QTableWidgetItem,QGridLayout)
from .capture import GameCapture, list_game_windows
from .catalog import catalog,operator_profiles,stage_previews
from .operator_summary import format_operator_observation
from .account_cache import AccountCache
from .run_state import RunState
from .record_flags import active_record
from .damage import calculate_damage
from .manual_scenario import parse_preview_object
from .relics import mechanics,matches
from .offline_scope import active_effects,partition
from .operator_options import OPTIONS
from .estimate import format_estimate
from .reporting import format_report
from .animation_reference import choices as animation_choices, label as animation_label
from .recognition import ScreenReader
from .map_reporting import format_map, format_node, format_rewards, format_route, format_connections, location
from .map_view import MapView
from .battle_view import BattlePreviewPanel
from .chat import ProviderConfig, stream_chat
from .credentials import save_key, read_key
from .desktop_backend import DesktopBackend
from .ui_state import replace_text,append_text
from .view_catalog import (operator_groups,stage_groups,enemy_groups,skill_icon,
                           SubjectPicture,PROFESSIONS,ENEMY_TIERS,profession_branch_icons)
from .branch_choice import BranchChoice

ROOT = Path(__file__).resolve().parents[1]
SETTINGS = ROOT / 'local-settings.json'
OPERATOR_STATE=ROOT/'.local/operator-state.json'
RUN_STATE=ROOT/'.local/run-state.json'

def apply_relic_history_notice(scenario,result):
    """Expose unresolved retained stats without applying a lost relic again."""
    inventory=scenario.get('inventory_status',{})
    context=scenario.get('relic_history_context',{})
    if (inventory.get('source')!='run_capture' or not context.get('run_id')
            or context['run_id']!=inventory.get('run_id')):return
    records=[record for record in context.get('persistent_growth_unknowns',[])
        if record.get('id')=='rogue_6_start_4'
        and record.get('source')=='same_run_confirmed_relic_history'
        and record.get('growth_status')=='unknown']
    if not records:return
    from copy import deepcopy
    result['relic_history_context']=deepcopy(context)
    warning=('襁褓九头蛇：本局曾确认持有；已获得的我方加成在失去藏品后仍保留。'
        '累计成长尚未确认，预计攻击与生命未包含这部分未知加成；当前数值仅供已支持效果参考，不能视为加成为0。'
        ' 来源：https://prts.wiki/index.php?title=沉沦者的黑流树海/拟造物质编目&oldid=433329')
    for status in (result['estimate'],result['relic_resolution']):
        status['complete']=False
        if warning not in status['warnings']:status['warnings'].append(warning)

class Events(QObject):
    sample = Signal(object)
    sample_error = Signal(object)
    error = Signal(str, str)
    chunk = Signal(str)
    chat_done = Signal(bool)
    desktop_state = Signal(object)

def number(value=0, maximum=100000, decimals=2):
    control = QDoubleSpinBox()
    control.setRange(0, maximum)
    control.setDecimals(decimals)
    control.setValue(value)
    return control

class MainWindow(QMainWindow):
    def show_barrier_ledger(self):
        panel=self.offline_tools
        panel.family.setCurrentIndex(panel.family.findData('calibration'))
        panel.query.setCurrentIndex(panel.query.findData('barrier-ledger'))
        self.centralWidget().setCurrentWidget(panel)

    def show_shield_grants(self):
        self.offline_tools.select_query('calibration','shield-grants')
        self.centralWidget().setCurrentWidget(self.offline_tools)

    def show_shield_inventory(self):
        self.offline_tools.select_query('calibration','shield-inventory')
        self.centralWidget().setCurrentWidget(self.offline_tools)

    def show_explosion_values(self):
        self.offline_tools.select_query('calibration','explosion-values')
        self.centralWidget().setCurrentWidget(self.offline_tools)

    def __init__(self, *, include_historical_route_diagnostics=False):
        super().__init__()
        from .information_scope import require_query_scope
        require_query_scope('exploration',None,include_historical_route_diagnostics)
        self.include_historical_route_diagnostics=include_historical_route_diagnostics
        self.setWindowTitle('黑流树海助手 0.91 · 局外计算与节点测试（234）')
        self.resize(1050, 830)
        self.capture = GameCapture()
        self.reader = ScreenReader()
        self.visual_reader = None
        self.events = Events()
        self.busy = False
        self.closing = False
        self.sample_epoch = 0
        self.last_sample_at = 0
        self.next_capture_attempt = 0
        self.observation = None
        self.map_frame = None
        self.map_frames = {}
        self.damage_result = None
        self.history = []
        self.chat_busy = False
        self.cancel_event = threading.Event()
        self.answer = ''
        self.desktop_snapshot = None
        self.desktop_request_busy = False
        self.last_chat_mode = 0
        self.account_cache=AccountCache(OPERATOR_STATE,operator_profiles(),catalog()['operators'])
        self.operator_observations=self.account_cache.records
        self.run=RunState(RUN_STATE)
        self.level_override=False
        self.skill_override=False
        self.display_operator=None
        self.last_observed_operator=None
        self.last_observed_stage=None
        self.map_detail_key=None
        self.damage_detail_key=None
        self.displayed_enemy_context=None
        self.transcript_key=None
        self.desktop = DesktopBackend(ROOT/'.local/desktop-chat',self.events.desktop_state.emit)
        self.events.sample.connect(self.sample_received)
        self.events.sample_error.connect(self.sample_failed)
        self.events.error.connect(self.show_error)
        self.events.chunk.connect(self.chat_chunk)
        self.events.chat_done.connect(self.chat_finished)
        self.events.desktop_state.connect(self.desktop_state_received)
        tabs = QTabWidget()
        self.setCentralWidget(tabs)
        tabs.addTab(self.make_capture_tab(), '采样测试')
        tabs.addTab(self.make_damage_tab(), '伤害测试')
        tabs.addTab(self.make_chat_tab(), '聊天分析')
        self.exploration_map_tab=self.make_map_tab()
        tabs.addTab(self.exploration_map_tab, '地图预览')
        self.battle_preview=BattlePreviewPanel()
        self.battle_preview.stageSelected.connect(self.select_battle_stage)
        tabs.addTab(self.battle_preview,'战斗预览')
        from .node_catalog_view import NodeCatalogPanel
        self.node_catalog=NodeCatalogPanel()
        self.node_catalog.stageSelected.connect(self.show_catalog_battle)
        self.node_catalog.mapNodeSelected.connect(self.show_catalog_map_node)
        tabs.addTab(self.node_catalog,'节点事件')
        from .offline_tools_view import OfflineToolsPanel
        self.offline_tools=OfflineToolsPanel(include_historical_route_diagnostics=include_historical_route_diagnostics)
        self.offline_tools.mapNodeSelected.connect(self.show_catalog_map_node)
        tabs.addTab(self.offline_tools,'局外工具')
        self.offline_tools.set_stage(self.target_stage.currentData())
        from .paired_calibration_view import PairedCalibrationPanel
        self.paired_calibration=PairedCalibrationPanel()
        tabs.addTab(self.paired_calibration,'前后校准')
        if include_historical_route_diagnostics:
            from .route_constraints_view import RouteConstraintsPanel
            self.route_constraints=RouteConstraintsPanel()
            self.route_constraints.mapNodeSelected.connect(self.show_catalog_map_node)
            tabs.addTab(self.route_constraints,'路线约束')
            from .route_resident_review_view import ResidentRouteReviewPanel
            self.resident_route_review=ResidentRouteReviewPanel()
            self.resident_route_review.mapNodeSelected.connect(self.show_catalog_map_node)
            tabs.addTab(self.resident_route_review,'居民路线')
            from .route_resource_ledger_view import RouteResourceLedgerPanel
            self.route_resource_ledger=RouteResourceLedgerPanel()
            self.route_resource_ledger.mapNodeSelected.connect(self.show_catalog_map_node)
            tabs.addTab(self.route_resource_ledger,'路线资源')
            from .route_scenarios_view import RouteScenarioMatrixPanel
            self.route_scenarios=RouteScenarioMatrixPanel()
            self.route_scenarios.mapNodeSelected.connect(self.show_catalog_map_node)
            tabs.addTab(self.route_scenarios,'多情景路线')
            from .route_continuation_view import RouteContinuationPanel
            self.route_continuation=RouteContinuationPanel()
            self.route_continuation.mapNodeSelected.connect(self.show_catalog_map_node)
            tabs.addTab(self.route_continuation,'路线续接')
        from .inventory_capacity_view import InventoryCapacityPanel
        self.inventory_capacity=InventoryCapacityPanel()
        tabs.addTab(self.inventory_capacity,'零件箱整理')
        from .attack_state_sequence_view import AttackStateSequencePanel
        self.attack_state_sequence=AttackStateSequencePanel()
        tabs.addTab(self.attack_state_sequence,'攻击状态序列')
        from .timing_calibration_view import TimingCalibrationPanel
        self.timing_calibration=TimingCalibrationPanel()
        tabs.addTab(self.timing_calibration,'时刻校准')
        from .bounded_calibration_view import BoundedCalibrationPanel
        self.bounded_calibration=BoundedCalibrationPanel()
        tabs.addTab(self.bounded_calibration,'有界校准')
        from .calibration_experiment_view import CalibrationExperimentPanel
        self.calibration_experiment=CalibrationExperimentPanel()
        tabs.addTab(self.calibration_experiment,'多记录实验')
        from .recipient_native_ratio_view import RecipientNativeRatioPanel
        self.recipient_native_ratio=RecipientNativeRatioPanel()
        tabs.addTab(self.recipient_native_ratio,'HP原值资格')
        from .relic_order_precision_view import RelicOrderPrecisionPanel
        self.relic_order_precision=RelicOrderPrecisionPanel()
        tabs.addTab(self.relic_order_precision,'藏品处理精度')
        from .technology_view import TechnologyReferencePanel
        self.technology_reference=TechnologyReferencePanel(account_path=Path(OPERATOR_STATE).with_name('technology-state.json'))
        tabs.addTab(self.technology_reference,'长期科技')
        self.battle_preview.set_stage(self.target_stage.currentData())
        self.timer = QTimer(self)
        self.timer.timeout.connect(lambda:self.sample_now(automatic=True))
        self.auto.toggled.connect(self.toggle_auto)
        self.refresh_windows()
        selected=self.run.state.get('selected_operator')
        if not selected:
            available=[key for key,member in self.run.state['operators'].items() if key in catalog()['operators'] and active_record(member,'present')]
            if len(available)==1:selected=available[0]
        if selected:self.select_operator(selected)
        self.update_operator()
        self.load_settings()
        self.sync_run_config()
        self.sync_run_relics()
        self.render_map()

    def make_capture_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        controls = QHBoxLayout()
        self.windows = QComboBox()
        controls.addWidget(self.windows,1)
        refresh = QPushButton('刷新窗口')
        refresh.clicked.connect(self.refresh_windows)
        controls.addWidget(refresh)
        self.connect_button = QPushButton('连接游戏')
        self.connect_button.clicked.connect(self.connect_game)
        controls.addWidget(self.connect_button)
        self.sample_button = QPushButton('一键采样')
        self.sample_button.clicked.connect(self.sample_now)
        controls.addWidget(self.sample_button)
        self.auto = QCheckBox('自动采样')
        controls.addWidget(self.auto)
        self.period = number(.1,5,2)
        self.period.setMinimum(.05)
        self.period.valueChanged.connect(lambda value: self.timer.setInterval(int(value*1000)))
        controls.addWidget(QLabel('自动检查秒'))
        controls.addWidget(self.period)
        self.sampling_status=QLabel('后台最多10帧/秒；有变化的画面自动排队识别，切页后继续提取。')
        self.sampling_status.setWordWrap(True)
        layout.addWidget(self.sampling_status)
        layout.addLayout(controls)
        methods=QHBoxLayout()
        self.recognition_mode=QComboBox()
        self.recognition_mode.addItem('视觉判页与区域 OCR','adaptive')
        self.recognition_mode.addItem('纯视觉试验（不调用 OCR，字段有限）','visual')
        self.recognition_mode.currentIndexChanged.connect(self.change_recognition_mode)
        methods.addWidget(QLabel('识别方案'))
        methods.addWidget(self.recognition_mode,1)
        layout.addLayout(methods)
        presets = QHBoxLayout()
        self.difficulty = QComboBox()
        for grade in catalog()['difficulties']:
            self.difficulty.addItem(f'保密等级 {grade}',grade)
        self.ending = QComboBox()
        for ending in catalog()['endings']:
            self.ending.addItem(ending['name'],ending['id'])
        presets.addWidget(QLabel('难度预设'))
        presets.addWidget(self.difficulty)
        presets.addWidget(QLabel('目标结局'))
        presets.addWidget(self.ending)
        presets.addStretch()
        layout.addLayout(presets)
        self.capture_status = QLabel('请连接游戏。截图只在内存中处理。')
        self.capture_status.setWordWrap(True)
        layout.addWidget(self.capture_status)
        self.run_summary=QLabel(self.run.summary())
        self.run_summary.setWordWrap(True)
        layout.addWidget(self.run_summary)
        self.reset_run_button=QPushButton('开始新局（清空本局读取，保留账号档案）')
        self.reset_run_button.clicked.connect(self.reset_run)
        layout.addWidget(self.reset_run_button)
        self.capture_operator_picture=SubjectPicture();layout.addWidget(self.capture_operator_picture)
        self.operator_summary=QPlainTextEdit('干员信息：等待自动读取详情页。')
        self.operator_summary.setReadOnly(True)
        self.operator_summary.setMaximumHeight(230)
        layout.addWidget(self.operator_summary)
        splitter = QSplitter(Qt.Orientation.Vertical)
        self.preview = QLabel('尚未采样')
        self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview.setMinimumHeight(180)
        splitter.addWidget(self.preview)
        self.observed_text = QPlainTextEdit()
        self.observed_text.setReadOnly(True)
        splitter.addWidget(self.observed_text)
        layout.addWidget(splitter,1)
        notice = QLabel('地图预测页提供模板匹配、隐藏节点候选及已揭示内容的奖励资料。具名事件奖励保留条件；宝箱与特殊敌人只列资料候选，完整掉落池和概率仍待核验。伤害页可选关卡敌人套用已支持的本局修正。')
        notice.setWordWrap(True)
        layout.addWidget(notice)
        return tab

    def make_map_tab(self):
        tab=QWidget();layout=QVBoxLayout(tab)
        notice=QLabel('点击节点查看类型、候选与相邻连接。青色＝已读类型，紫色＝隐藏候选，橙色＝本局历史；灰虚线＝模板全部连线。绿色圈＝当前确认位置，橙虚线圈＝历史位置。节点信息不代表可通行，也不自动选择或推荐路线。')
        if self.include_historical_route_diagnostics:
            notice.setText('历史路线诊断：蓝绿色路线＝途中类型符合穿越条件；橙虚线路线＝仅拓扑参考，实际阻碍仍待确认。')
        notice.setWordWrap(True);layout.addWidget(notice)
        self.map_mode=QLabel();self.map_mode.setWordWrap(True);layout.addWidget(self.map_mode)
        self.movement_source_button=QPushButton('加工品获取清单与来源机会')
        self.movement_source_button.clicked.connect(self.show_movement_sources)
        layout.addWidget(self.movement_source_button);self.movement_source_dialog=None
        self.fruit_marker_button=QPushButton('藏果地标记：核对声明探索与密道保留')
        self.fruit_marker_button.clicked.connect(self.show_fruit_marker_flow)
        layout.addWidget(self.fruit_marker_button);self.fruit_marker_dialog=None
        self.map_content=QLabel();self.map_content.setWordWrap(True);layout.addWidget(self.map_content)
        self.map_view=MapView(include_historical_route_diagnostics=self.include_historical_route_diagnostics)
        self.map_view.nodeSelected.connect(self.map_node_selected)
        layout.addWidget(self.map_view,4)
        self.map_nodes=QComboBox();self.map_nodes.setAccessibleName('按地图位置选择节点')
        self.map_nodes.currentIndexChanged.connect(lambda: self.map_view.select_node(self.map_nodes.currentData()))
        layout.addWidget(self.map_nodes)
        self.map_route=QLabel('请选择地图节点查看位置与相邻连接。');self.map_route.setWordWrap(True)
        self.map_route.setAccessibleName('所选节点连接信息');layout.addWidget(self.map_route)
        self.map_detail=QPlainTextEdit();self.map_detail.setReadOnly(True)
        self.map_detail.setPlaceholderText('点击预览图上的节点查看详细依据；也可在上方按位置选择。')
        self.map_detail.setMaximumHeight(150);layout.addWidget(self.map_detail,1)
        self.map_technical=QCheckBox('显示技术资料（全部节点、原始标识与来源）');layout.addWidget(self.map_technical)
        self.map_text=QPlainTextEdit();self.map_text.setReadOnly(True)
        self.map_text.setVisible(False);self.map_technical.toggled.connect(self.map_text.setVisible)
        self.map_technical.toggled.connect(lambda:self.map_node_selected(self.map_view.selected))
        layout.addWidget(self.map_text,1)
        return tab

    def map_node_selected(self, node_id):
        graph=self.map_view.graph or {}
        if self.include_historical_route_diagnostics:
            self.map_route.setText(format_route(self.map_view.graph,node_id,historical=self.map_view.historical,compact=True)
                                   if node_id else '请选择地图上的节点查看路线。')
        else:
            self.map_route.setText(format_connections(self.map_view.graph,node_id,historical=self.map_view.historical))
        key=(graph.get('zone_id'),graph.get('template_id'),node_id,self.map_technical.isChecked())
        replace_text(self.map_detail,format_node(self.map_view.graph,node_id,historical=self.map_view.historical,
                     technical=self.map_technical.isChecked(),
                     include_historical_route_diagnostics=self.include_historical_route_diagnostics),
                     preserve=self.map_detail_key==key)
        self.map_detail_key=key
        if hasattr(self,'node_catalog'):
            from .node_catalog_view import map_conditions
            self.node_catalog.set_node(graph,node_id,**map_conditions(graph,self.run.state.get('config',{})))
        self.map_nodes.blockSignals(True)
        self.map_nodes.setCurrentIndex(max(0,self.map_nodes.findData(node_id or None)))
        self.map_nodes.blockSignals(False)

    def render_map(self):
        current=(self.observation or {}).get('map')
        zid=(current or {}).get('zone_id') or self.run.state.get('config',{}).get('zone',{}).get('id')
        remembered=self.run.state.get('maps',{}).get(zid)
        captured=(self.observation or {}).get('captured_at')
        fresh=bool(current and current.get('status')=='matched' and remembered and
                   current.get('template_id')==remembered.get('template_id') and
                   captured==remembered.get('captured_at') and captured>=self.run.state['started_at'] and self.map_frame is not None)
        if fresh:
            self.map_frames[zid]=(remembered['template_id'],captured,self.map_frame)
        saved=self.map_frames.get(zid)
        paired=bool(remembered and saved and saved[:2]==(remembered['template_id'],remembered.get('captured_at')))
        image=saved[2] if paired else None
        if not remembered:
            mode='尚无可用地图记录；等待充分匹配的后台采样。'
        elif fresh:
            mode=f"当前画面 · {time.strftime('%H:%M:%S',time.localtime(captured))}采样 · 模板 {remembered['template_id']} · 点击节点查看完整候选；候选不是概率。"
        else:
            mode=('历史画面' if paired else '历史示意图')+f" · 模板 {remembered['template_id']} · 仅作本局历史参考。"
        if not fresh and current and current.get('reason'):
            mode+=' 本帧：'+current['reason']
        self.map_mode.setText(mode)
        content=((self.observation or {}).get('node_content') if captured is None or captured>=self.run.state['started_at'] else None) or self.run.state.get('last_node_content')
        if content:
            bound=content.get('location') or (((self.observation or {}).get('map') or {}).get('content_binding'))
            summary='最近内容读取：'+content['title']+'（'+('已定位到节点' if bound else '位置未确认，不自动绑定当前位置')+'）'
            if content.get('kind')=='event':
                summary+=f"；流程阶段{len(content.get('scene_candidates',[]))}个候选"
        else:summary='具体事件/关卡需读取详情确认；同一节点类型可以包含不同内容，未揭示时不臆测事件。'
        self.map_content.setText(summary)
        report=format_map(current if not current or current.get('status')!='matched' or fresh else None,remembered,technical=True)
        if content:
            report+='\n\n最近读取内容（位置未确认时仅作独立参考）：\n'+format_rewards(content,technical=True)
        replace_text(self.map_text,report)
        self.map_nodes.blockSignals(True);self.map_nodes.clear();self.map_nodes.addItem('请选择地图上的节点',None)
        if remembered:
            for node in sorted(remembered['nodes'],key=lambda n:(n['row'],n['col'])):
                self.map_nodes.addItem(location(node,remembered['grid']['rows']),node['id'])
        self.map_nodes.blockSignals(False)
        self.map_view.set_map(remembered,image,historical=not fresh)
        from .node_catalog_view import map_conditions
        from .event_run_context import observed_event_context
        context=observed_event_context(self.run)
        self.node_catalog.set_map_context(remembered,map_conditions(remembered,self.run.state.get('config',{})),
            epoch=self.run.state['id'],historical=not fresh,runtime_context=context)
        self.offline_tools.set_graph(remembered,epoch=self.run.state['id'],historical=not fresh)
        if self.include_historical_route_diagnostics:
            self.route_constraints.set_graph(remembered,epoch=self.run.state['id'],historical=not fresh)
            self.resident_route_review.set_graph(remembered,epoch=self.run.state['id'],historical=not fresh)
            self.route_resource_ledger.set_graph(remembered,epoch=self.run.state['id'],historical=not fresh)
            self.route_scenarios.set_graph(remembered,epoch=self.run.state['id'],historical=not fresh)
            self.route_continuation.set_graph(remembered,epoch=self.run.state['id'],historical=not fresh)
        if self.movement_source_dialog:
            self.movement_source_dialog.set_map_context(remembered if fresh else None,
                context=self.observed_event_context() if fresh else {},epoch=self.run.state['id'])

    def refresh_windows(self):
        if self.busy:
            return
        previous=self.windows.currentData() or {}
        key=(previous.get('hwnd'),previous.get('pid'))
        self.windows.blockSignals(True)
        self.windows.clear()
        for target in list_game_windows():
            self.windows.addItem(f'{target["title"]} · PID {target["pid"]}' + (' · 最小化' if target['minimized'] else ''),target)
        index=next((i for i in range(self.windows.count()) if
                    (self.windows.itemData(i).get('hwnd'),self.windows.itemData(i).get('pid'))==key),0)
        self.windows.setCurrentIndex(index if self.windows.count() else -1)
        self.windows.blockSignals(False)
        if not self.windows.count():
            self.capture_status.setText('未找到 Arknights.exe 游戏窗口；请打开原生客户端后刷新。')

    def connect_game(self):
        if self.busy:
            return
        target = self.windows.currentData()
        if not target:
            self.capture_status.setText('请打开游戏并刷新窗口列表。')
            return
        try:
            self.capture.connect(target)
            self.sample_epoch += 1
            self.capture.set_collecting(self.auto.isChecked())
            self.capture_status.setText('已连接；点击一键采样，或开启自动采样。')
        except Exception as error:
            self.capture_status.setText(str(error))

    def toggle_auto(self, checked):
        if checked:
            self.capture.set_collecting(True)
            if self.capture.target is None:
                self.connect_game()
            self.timer.start(int(self.period.value()*1000))
            self.sample_now(automatic=True)
        else:
            self.timer.stop()
            self.sample_epoch += 1
            self.capture.set_collecting(False)
            self.capture_status.setText('自动采样已暂停；保留上次观测。')

    def update_sampling_status(self):
        stats=self.capture.stats()
        age=max(0,time.time()-stats['oldest_at']) if stats.get('oldest_at') else 0
        self.sampling_status.setText(f"后台最多10帧/秒 · 待识别{stats['pending']}帧 · 缓存{stats['bytes']/1048576:.1f} MiB"
            +(f' · 最早等待{age:.1f}秒' if stats['pending'] else '')
            +(f" · 缓存已满丢弃{stats['overflow']}帧" if stats['overflow'] else '')
            +(f" · 超出单帧预算{stats['oversized']}帧" if stats.get('oversized') else ''))

    def change_recognition_mode(self):
        self.sample_epoch += 1
        self.capture.discard_pending()
        if self.auto.isChecked():QTimer.singleShot(0,lambda:self.sample_now(automatic=True))

    def sample_now(self, checked=False, *, automatic=False):
        if automatic and not self.auto.isChecked():return
        self.update_sampling_status()
        if self.busy or self.closing:
            return
        if automatic and time.monotonic()<self.next_capture_attempt:return
        self.capture.set_collecting(True)
        if self.capture.target is None:
            targets = list_game_windows()
            if len(targets) == 1:
                try:
                    self.capture.connect(targets[0])
                    self.sample_epoch += 1
                except Exception as error:
                    self.capture_status.setText(str(error))
            else:
                self.connect_game()
            if self.capture.target is None:
                if not self.auto.isChecked():self.capture.set_collecting(False)
                self.next_capture_attempt=time.monotonic()+1
                self.capture_status.setText('等待游戏窗口；自动模式会继续重试。' if self.auto.isChecked() else '请连接游戏窗口。')
                return
        self.capture.set_collecting(True)
        capture_start=time.perf_counter()
        try:
            frame=self.capture.next_frame(force=not automatic)
        except Exception as error:
            self.show_error('capture',str(error))
            return
        if frame is None and automatic:return
        epoch=self.sample_epoch
        generation=self.capture.stats()['generation']
        self.busy = True
        self.sample_button.setEnabled(False)
        self.connect_button.setEnabled(False)
        self.capture_status.setText('正在提取已捕获页面；后台仍继续采集…')
        mode=self.recognition_mode.currentData()
        run_context=self.run.recognition_context()
        self.recognition_mode.setEnabled(False)
        def work():
            try:
                selected = frame
                deadline=time.monotonic()+4
                while selected is None:
                    if time.monotonic()>=deadline:raise TimeoutError('未收到新的游戏画面。')
                    if self.closing or epoch!=self.sample_epoch:raise RuntimeError('本次采样已失效。')
                    selected=self.capture.next_frame(force=True)
                    if selected is None:time.sleep(.02)
                capture_ms=(time.perf_counter()-capture_start)*1000
                if mode=='visual':
                    if self.visual_reader is None:
                        from .visual_recognition import VisualReader
                        self.visual_reader=VisualReader()
                    reader=self.visual_reader
                else:reader=self.reader
                for attempt in range(2):
                    try:
                        observation = reader.read(selected['image'],client_rect=selected.get('client_rect'),run_context=run_context)
                        break
                    except Exception:
                        if attempt or self.closing or epoch!=self.sample_epoch:raise
                        # Retry a transient local recognition failure once using
                        # this saved page, even if the user has already left it.
                        time.sleep(.25)
                observation['capture_ms']=capture_ms
                observation['captured_at'] = selected['captured_at']
                observation['_sampling']={'epoch':epoch,'generation':generation,'seq':selected.get('seq')}
                observation['_sampling']['recognition_attempts']=attempt+1
                self.events.sample.emit((selected['image'],observation))
            except Exception as error:
                self.events.sample_error.emit((epoch,generation,str(error)))
        threading.Thread(target=work,daemon=True).start()

    def finish_sample(self):
        self.busy=False
        self.recognition_mode.setEnabled(True)
        self.sample_button.setEnabled(True)
        self.connect_button.setEnabled(True)
        if self.auto.isChecked():
            QTimer.singleShot(0,lambda:self.sample_now(automatic=True))
        else:self.capture.set_collecting(False)

    def sample_failed(self, result):
        if self.closing:return
        epoch,generation,message=result
        valid=epoch==self.sample_epoch and generation==self.capture.stats()['generation']
        self.finish_sample()
        if valid:
            self.show_error('capture',message)

    def sample_received(self, result):
        if self.closing:
            return
        ui_start=time.perf_counter()
        image, observation = result
        marker=observation.get('_sampling')
        valid=not marker or (marker['epoch']==self.sample_epoch and marker['generation']==self.capture.stats()['generation'])
        self.finish_sample()
        if not valid or observation.get('captured_at',0)<max(self.last_sample_at,self.run.state['started_at']):return
        self.last_sample_at=observation['captured_at']
        self.observation = observation
        stage=observation.get('stage')
        if observation.get('page')=='node_detail' and stage:
            sid=stage.get('visible_variant_id') or stage.get('id')
            key=(sid,stage['name'])
            if key!=self.last_observed_stage:
                self.last_observed_stage=key
                if sid or (self.target_stage.currentData() and catalog()['stages'][self.target_stage.currentData()]['name']!=stage['name']):
                    self.target_stage_choices.select_value(sid)
            self.target_stage.setToolTip('最近节点详情：'+stage['name']+'；'+stage.get('variant_source','普通/紧急变体尚未确认，请选择明确的测试关卡。'))
        run_applied=False
        if observation.get('run'):
            run_applied=self.apply_run_observation(observation['run'],observation.get('captured_at',time.time()))
        if observation.get('operator'):
            self.apply_operator_observation(observation['operator'],observation.get('captured_at',time.time()))
            saved=self.account_cache.view(observation['operator']['id'])
            profile=operator_profiles()[observation['operator']['id']]
            self.capture_operator_picture.set_subject('operator',observation['operator']['id'],
                profile['name']+' · '+PROFESSIONS[profile['profession']])
            note='本帧纯视觉只确认身份与已匹配潜能；其余项来自以前已确认记录。\n' if observation.get('performance',{}).get('backend')=='visual' else ''
            account_notice=self.account_cache.notice(observation['operator']['id'])
            summary=format_operator_observation(saved) if saved else '本帧干员档案尚未确认；未使用不可用的账号记录。'
            replace_text(self.operator_summary,note+summary+('\n'+account_notice if account_notice else ''))
        elif run_applied and (observation.get('run') or {}).get('selected_operator'):
            selected=observation['run']['selected_operator']
            profile=operator_profiles()[selected]
            self.capture_operator_picture.set_subject('operator',selected,profile['name']+' · '+PROFESSIONS[profile['profession']])
            from .training_view import format_run_training_observation
            replace_text(self.operator_summary,format_run_training_observation(selected,self.run.state['operators'][selected]))
        else:
            self.capture_operator_picture.set_subject(None,None,'')
            replace_text(self.operator_summary,'本帧未确认新的干员培养信息；本局已确认记录继续保留，见本局状态与计算页。')
        rgb = image[:,:,::-1].copy()
        height,width,_ = rgb.shape
        qimage = QImage(rgb.data,width,height,rgb.strides[0],QImage.Format.Format_RGB888).copy()
        self.map_frame=qimage
        self.preview.setPixmap(QPixmap.fromImage(qimage).scaled(self.preview.size(),Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
        replace_text(self.observed_text,json.dumps(observation,ensure_ascii=False,indent=2))
        performance=observation.get('performance',{})
        timing=f" · 识别{performance['total_ms']/1000:.2f}秒" if 'total_ms' in performance else ''
        self.render_map()
        reuse=' · 静帧精确复用' if performance.get('reuse')=='exact_frame' else ''
        backend=' · 纯视觉' if performance.get('backend')=='visual' else ' · 动态OCR'
        if performance.get('feature_cache_hits',0):reuse+=' · 特征精确复用'
        routing=performance.get('routing',{})
        if routing.get('feature_reuse')=='exact_controls':reuse+=' · 核心控件精确复用'
        if routing.get('strategy')=='visual_region_ocr':reuse+=' · 页面区域优先'
        batch_hits=performance.get('ocr',{}).get('reused_batches',0)
        if batch_hits:reuse+=f' · 文字批精确复用{batch_hits}组'
        if routing.get('fallback_reason')=='page_outside_regions_changed':reuse+=' · 页外变化已完整复核'
        capture_timing=f" · 采集{observation['capture_ms']/1000:.2f}秒" if 'capture_ms' in observation else ''
        ui_timing=f' · 界面更新{time.perf_counter()-ui_start:.2f}秒'
        age=max(0,time.time()-observation['captured_at'])
        stamp=time.strftime('%H:%M:%S',time.localtime(observation['captured_at']))
        self.capture_status.setText(f'画面{stamp}（{age:.1f}秒前） · {width}×{height} · {observation["page"]} · {len(observation["nodes"])} 个可见标签。'+backend+capture_timing+timing+ui_timing+reuse)
        self.update_sampling_status()

    def make_damage_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        columns = QHBoxLayout()
        form = QFormLayout()
        self.damage_form=form
        self.operator = QComboBox()
        profiles=operator_profiles()
        self.operator_choices=BranchChoice(self.operator,operator_groups(profiles,catalog()['operators']),
            overview_label='总览（已招募）',overview=self.recruited_operator_ids(),empty_label='本局尚无已确认招募干员',
            branch_icons=profession_branch_icons())
        self.operator_choices.select_value('kaltsit',emit=False)
        self.operator.currentIndexChanged.connect(self.update_operator)
        form.addRow('职业 / 干员',self.operator_choices)
        self.operator_picture=SubjectPicture();form.addRow(self.operator_picture)
        self.use_run_training=QCheckBox('使用已读取的本局培养；缺失项明确显示参考来源')
        self.use_run_training.setChecked(True)
        self.use_run_training.toggled.connect(lambda:self.update_operator())
        form.addRow(self.use_run_training)
        self.elite=QLabel('未确认')
        self.level=QSpinBox()
        self.level.setRange(1,90);self.level.setValue(90)
        self.trust=QLabel('未确认')
        self.potential=QLabel('未确认')
        self.module=QLabel('未确认')
        training=QHBoxLayout()
        training.addWidget(self.level)
        restore_level=QPushButton('使用读取等级')
        restore_level.clicked.connect(lambda:self.update_operator())
        training.addWidget(restore_level)
        form.addRow('等级（可模拟调整）',training)
        form.addRow('精英阶段（自动读取）',self.elite)
        form.addRow('信赖（自动读取）',self.trust)
        form.addRow('潜能（自动读取）',self.potential)
        form.addRow('模组（自动读取）',self.module)
        self.training_status=QLabel('进入干员详情页，由后台采样自动读取；未确认字段不冒充当前状态。')
        self.training_status.setWordWrap(True)
        form.addRow(self.training_status)
        self.level.valueChanged.connect(self.level_changed)
        self.skill = QComboBox()
        self.skill.setIconSize(QSize(28,28))
        self.skill.currentIndexChanged.connect(self.skill_changed)
        form.addRow('技能',self.skill)
        self.skill_picture=SubjectPicture(edge=48);form.addRow(self.skill_picture)
        self.rank=QLabel('未确认')
        form.addRow('技能等级（自动读取）',self.rank)
        self.account_skill_reference_key=None
        self.account_skill_reference=QCheckBox('选择账号已读技能等级作局外模拟参考（仅当前技能）')
        self.account_skill_reference.toggled.connect(lambda:self.update_skill_options())
        form.addRow(self.account_skill_reference)
        self.run_common_skill_reference=QCheckBox('选择本局已读公共等级作其它技能的局外参考')
        self.run_common_skill_reference.toggled.connect(lambda:self.update_skill_options())
        form.addRow(self.run_common_skill_reference)
        self.skill_cultivation_row=None
        self.skill_cultivation_explanation=QLabel('')
        self.skill_cultivation_explanation.setWordWrap(True)
        form.addRow('技能培养来源与资格',self.skill_cultivation_explanation)
        form.setRowVisible(self.skill_cultivation_explanation,False)
        self.attack=QLabel('由培养档案计算')
        # Kept as an internal compatibility value; the visible result includes effects.
        self.attack.hide()
        self.deployment_elapsed=number(0,3600,2)
        form.addRow('预计在场时间（秒，影响银灰天赋）',self.deployment_elapsed)
        self.healing_targets=QSpinBox()
        self.healing_targets.setRange(0,100);self.healing_targets.setValue(1)
        form.addRow('满额受疗目标数（当前技能）',self.healing_targets)
        self.continuous_attacks=QCheckBox('持续进行普攻以回复技力')
        self.continuous_attacks.setChecked(True)
        self.continuous_attacks.setToolTip('声明估算时是否持续普攻；自然回复技能也可能通过适用的天赋或藏品使用此条件。显示此项不表示必有额外技力。未核验的技力来源仅作资料参考，未知回转保持未知。')
        self.continuous_attacks.toggled.connect(lambda:self.calculate())
        form.addRow('普攻回技力条件',self.continuous_attacks)
        self.defense = number(0,100000,0)
        self.target_stage=QComboBox()
        self.target_stage_choices=BranchChoice(self.target_stage,
            stage_groups({sid:s for sid,s in catalog()['stages'].items() if sid in stage_previews()}),
            overview_label='总览（全部关卡）',placeholder='手动目标测试')
        self.target_enemy=QComboBox();self.target_enemy.addItem('选择关卡候选敌人',None)
        self.target_enemy_choices=BranchChoice(self.target_enemy,[],overview_label='总览（当前关卡）',
            placeholder='选择关卡候选敌人')
        form.addRow('层数 / 目标关卡',self.target_stage_choices)
        form.addRow('档次 / 目标敌人',self.target_enemy_choices)
        self.target_enemy_picture=SubjectPicture();form.addRow(self.target_enemy_picture)
        form.setRowVisible(self.target_enemy_picture,False)
        self.target_stage.currentIndexChanged.connect(self.update_target_enemies)
        self.target_enemy.currentIndexChanged.connect(self.update_enemy_context)
        self.orb_mode=QComboBox()
        self.orb_mode.addItem('阶段/来源列未确认；仅显示未减伤参考','unknown')
        self.orb_mode.addItem('全程行动模式；所有来源均在目标占据列内','active_same_column')
        self.orb_mode.addItem('全程行动模式；所有来源均在目标占据列外','active_other_column')
        form.addRow('源阶方情景（测试）',self.orb_mode)
        form.setRowVisible(self.orb_mode,False)
        self.orb_mode.currentIndexChanged.connect(lambda:self.calculate() if hasattr(self,'raw_damage') else None)
        form.addRow('手动目标防御（测试）',self.defense)
        self.resistance = number(0,100,1)
        form.addRow('手动目标法抗 %（测试）',self.resistance)
        self.window_seconds = number(40,3600,2)
        self.limit_window = QCheckBox('使用指定观察窗口（秒）')
        self.limit_window.setToolTip('只改变当前技能模型的观察范围，不把输入秒数当作技能持续时间；实际已计窗口见报告。已计窗口为0秒时不计算窗口平均DPS/HPS，未定位来源与未知回转仍保持原说明。')
        self.window_seconds.setToolTip('只改变当前技能模型的观察范围，不把输入秒数当作技能持续时间；实际已计窗口见报告。已计窗口为0秒时不计算窗口平均DPS/HPS，未定位来源与未知回转仍保持原说明。')
        self.limit_window.toggled.connect(lambda:self.calculate())
        self.window_seconds.valueChanged.connect(lambda:self.calculate())
        form.addRow(self.limit_window,self.window_seconds)
        self.frame_timing=QCheckBox('使用逐帧时序估算（未校准项会标注）')
        self.frame_timing.setChecked(True)
        form.addRow(self.frame_timing)
        self.normal_animation_reference=QComboBox()
        self.skill_animation_reference=QComboBox()
        self.animation_preview_key=None;self.animation_previews={}
        for title,widget in (('普攻阶段原版动作参考',self.normal_animation_reference),
                             ('技能阶段原版动作参考',self.skill_animation_reference)):
            form.addRow(title,widget)
            widget.setToolTip('可选的局外时序参考；默认不选。部分默认外观与模式的静态动作选择已核验；动画内事件帧仅为条件参考，实际外观、回调和起止相位仍待核验。不会写入培养或本局记忆。')
            widget.currentIndexChanged.connect(lambda:self.calculate())
        self.chen_motion_orientation=QComboBox()
        self.chen_motion_orientation.addItem('不显示原版阶段资料',None)
        self.chen_motion_orientation.addItem('正面原版动作资料','Front')
        self.chen_motion_orientation.addItem('背面原版动作资料','Back')
        self.chen_motion_orientation.addItem('正背面原版动作对照','both')
        self.chen_motion_preview_key=None;self.chen_motion_previews={}
        form.addRow('陈原版阶段资料',self.chen_motion_orientation)
        form.setRowVisible(self.chen_motion_orientation,False)
        self.chen_motion_orientation.setToolTip('仅显示当前技能的原版动作资源长度与全部命名事件；不排程多段伤害，不补齐斩击结束、剑气碰撞或技能结束。连续与逐帧模式均可查看，不写入培养或本局记忆。')
        self.chen_motion_orientation.currentIndexChanged.connect(lambda:self.calculate())
        self.timing_scenario=QPlainTextEdit()
        self.timing_scenario.setMaximumHeight(85)
        self.timing_scenario.setPlaceholderText('可留空。情景JSON示例：{"target_windows":[[0,5],[8,20]],"movement_windows":[[2,3]]}')
        self.timing_scenario.setToolTip('秒数以技能开启为0；初动使用initial_target_windows等独立部署时间轴。此处为测试情景，当前尚未从战斗画面自动跟踪。动画参考值会自动加载；不要在这里填写培养属性。区间按30Hz模拟帧换算，换算后结束须晚于开始。关闭逐帧时，明确的空供靶列表（target_windows:[]）取消适用的敌方普通攻击与瞬时命中参考；独立单位仅消费各自的空供靶声明，友方潜在治疗另按受疗条件处理，独立或未定位来源仍保留各自条件。永久攻击在空供靶时保留出手与相应技力参考，但不产生已建模敌方命中；独立音符的实际碰撞仍按原说明保持未知。非空供靶、移动和中断区间不在连续模式下逐帧调度；目标消失声明继续按原范围处理，未知时钟不补算。')
        self.timing_preview_key=None;self.timing_previews={}
        form.addRow('战斗时序情景（测试，可留空）',self.timing_scenario)
        self.frame_timing.toggled.connect(lambda:self.calculate())
        self.timing_scenario.textChanged.connect(lambda:self.calculate())
        self.relic_context=QPlainTextEdit()
        self.relic_context.setMaximumHeight(65)
        self.relic_context.setPlaceholderText('测试条件 JSON，例如 {"gold":25,"deployed_casters":2}；留空使用本局已确认记录')
        self.relic_context.setToolTip('只使用当前藏品所需条件；测试值不写入本局记忆。实际在场术师不能用队伍术师人数代替；应急身份从队伍标识读取。')
        self.relic_context_previews={}
        form.addRow('当前藏品条件（测试）',self.relic_context)
        form.setRowVisible(self.relic_context,False)
        self.relic_context.textChanged.connect(lambda:self.calculate())
        self.target_buff_status=QLabel('个人强化归属尚未确认')
        self.target_buff_status.setWordWrap(True)
        form.addRow('本局个人强化（读取）',self.target_buff_status)
        self.target_buff_test=QCheckBox('测试定向强化（不写入本局记忆）')
        form.addRow(self.target_buff_test)
        self.target_buff_list=QListWidget();self.target_buff_list.setMaximumHeight(110)
        form.addRow('当前干员强化测试',self.target_buff_list)
        form.setRowVisible(self.target_buff_list,False)
        self.target_preview_operator=None;self.target_buff_previews={}
        self.target_buff_test.toggled.connect(lambda:self.calculate())
        self.target_buff_list.itemChanged.connect(lambda:self.calculate())
        self.cooperative = QCheckBox('协同攻击持续覆盖同一目标')
        form.addRow('银灰 S3',self.cooperative)
        self.fragile = QCheckBox('全程计该技能脆弱（不勾选则全程未计）')
        self.fragile.setChecked(True)
        form.addRow('银灰 S3',self.fragile)
        self.charge_count = QSpinBox()
        self.charge_count.setRange(0,100)
        form.addRow('机械师 S3 命中冲锋次数',self.charge_count)
        self.shield_breaks = QSpinBox()
        self.shield_breaks.setRange(0,100)
        form.addRow('机械师 S2 本次实际/预计总破屏次数',self.shield_breaks)
        self.shield_breaks.setToolTip('本体与结构性原理的爆炸中，命中当前目标的总次数。用于条件估算，不自动推断弹药消耗。')
        self.barrier_ledger_button=QPushButton('打开有序入伤屏障账本（局外声明）')
        self.barrier_ledger_button.clicked.connect(self.show_barrier_ledger)
        form.addRow('机械师 S2',self.barrier_ledger_button)
        self.shield_grant_button=QPushButton('初始屏障与藏品生命参考')
        self.shield_grant_button.clicked.connect(self.show_shield_grants)
        form.addRow('机械师 S2',self.shield_grant_button)
        self.shield_inventory_button=QPushButton('按来源汇总屏障与溢出门（局外声明）')
        self.shield_inventory_button.clicked.connect(self.show_shield_inventory)
        form.addRow('机械师 S2',self.shield_inventory_button)
        self.explosion_values_button=QPushButton('爆炸双分支定点计算（独立快照）')
        self.explosion_values_button.clicked.connect(self.show_explosion_values)
        form.addRow('机械师 S2',self.explosion_values_button)
        self.shield_duration_known=QCheckBox('指定本次技能结束时间（含手动停止）')
        self.shield_duration=number(30,3600,2)
        self.shield_duration.setMinimum(.01)
        self.shield_duration.setEnabled(False)
        self.shield_duration_known.toggled.connect(self.shield_duration.setEnabled)
        form.addRow(self.shield_duration_known,self.shield_duration)
        self.activation_count = QSpinBox()
        self.activation_count.setRange(0,100)
        self.activation_count.setValue(1)
        form.addRow('银灰 S2 本体施放次数',self.activation_count)
        self.companion_attack = number(1000,100000,0)
        form.addRow('银灰 S2 受益者实际攻击',self.companion_attack)
        self.stacks = QSpinBox()
        self.stacks.setRange(0,2)
        form.addRow('银灰 S2 部署触发叠层',self.stacks)
        self.model_option_widgets=[]
        for operator,entries in OPTIONS.items():
            for key,label,default,maximum,skills in entries:
                if key=='healing_targets':continue
                if default is None:
                    from .susuro_healing_view import RecipientRatioInput
                    widget=RecipientRatioInput()
                    widget.setToolTip('受疗者独立生命比例情景；不使用干员自身生命、缺失生命或截图百分比推断。基包LE比较有Q32.32容差，恰好50%也生效；实际血量变化及时钟未知。')
                    if key=='guardian_healing_target_hp_ratio':
                        widget.setToolTip('受疗者独立固定生命比例；古米LT阈值减容差，黍LE阈值加容差。实际血量变化、友方获取与治疗时钟未知。')
                    widget.valueChanged.connect(lambda:self.calculate())
                elif isinstance(default,bool):
                    widget=QCheckBox(label);widget.setChecked(default)
                    widget.toggled.connect(lambda:self.calculate())
                elif isinstance(default,int):
                    widget=QSpinBox();widget.setRange(0,maximum);widget.setValue(default)
                    if key=='amiya_hit_targets':widget.setMinimum(1)
                    widget.valueChanged.connect(lambda:self.calculate())
                else:
                    widget=number(default,maximum,2)
                    widget.valueChanged.connect(lambda:self.calculate())
                form.addRow(label,widget)
                form.setRowVisible(widget,False)
                self.model_option_widgets.append((operator,key,skills,widget))
        self.condition_cultivation_rows=[]
        self.condition_cultivation_explanation=QLabel('')
        self.condition_cultivation_explanation.setWordWrap(True)
        form.addRow('条件培养来源',self.condition_cultivation_explanation)
        form.setRowVisible(self.condition_cultivation_explanation,False)
        from .condition_cultivation import TARGET_OPERATORS,TARGET_FIELDS
        for owner,key,skills,widget in self.model_option_widgets:
            if owner not in TARGET_OPERATORS or key not in TARGET_FIELDS:continue
            signal=widget.toggled if isinstance(widget,QCheckBox) else widget.valueChanged
            signal.connect(lambda _value:self.update_condition_cultivation_explanations(
                self.operator.currentData(),self.skill.currentData()))
        columns.addLayout(form,1)
        relic_layout = QVBoxLayout()
        self.auto_relics=QCheckBox('使用本局自动读取的藏品')
        self.auto_relics.setChecked(True)
        self.auto_relics.toggled.connect(self.sync_run_relics)
        relic_layout.addWidget(self.auto_relics)
        self.relic_filter = QLineEdit()
        self.relic_filter.setPlaceholderText('搜索藏品；选中的藏品参与算例')
        self.relic_filter.textChanged.connect(self.filter_relics)
        relic_layout.addWidget(self.relic_filter)
        self.relic_list = QListWidget()
        for rid,relic in catalog()['relics'].items():
            proof=mechanics()['relics'][rid]
            active,reference,pending,reference_pending=partition(proof,rid)
            labels={'numeric':'有数值规则','conditional':'需条件','partial':'部分规则','pending':'机制待接入','non_output':'无输出加成'}
            label='仅作效果资料' if (reference or reference_pending) and not (active or pending) else '稳定部分可算，战斗部分仅资料' if reference or reference_pending else labels[proof['status']]
            if proof.get('recipient_binding'):label='需确认当前干员强化归属'
            item = QListWidgetItem(relic['name']+' ['+label+']')
            item.setData(Qt.ItemDataRole.UserRole,rid)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(Qt.CheckState.Unchecked)
            item.setToolTip((relic.get('usage') or '')+'\n'+label+'\n'+ '、'.join(pending)+'\n来源：'+proof['source'])
            self.relic_list.addItem(item)
        relic_layout.addWidget(self.relic_list)
        self.relic_list.itemChanged.connect(lambda:self.calculate() if not self.auto_relics.isChecked() else None)
        columns.addLayout(relic_layout,1)
        input_widget=QWidget();input_widget.setLayout(columns)
        scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(input_widget)
        layout.addWidget(scroll,2)
        calculate = QPushButton('计算属性与技能预估')
        calculate.clicked.connect(self.calculate)
        layout.addWidget(calculate)
        self.token_comparison_button=QPushButton('比较召唤物模组升级（局外参考）')
        self.token_comparison_button.clicked.connect(self.show_token_module_comparison)
        layout.addWidget(self.token_comparison_button)
        self.token_budget_button=QPushButton('测算召唤物费用与配额（局外参考）')
        self.token_budget_button.clicked.connect(self.show_token_budget)
        layout.addWidget(self.token_budget_button)
        self.wang_resource_button=QPushButton('望S1/S2：核对卡片与跟子分池资源链')
        self.wang_resource_button.setVisible(False)
        self.wang_resource_button.clicked.connect(self.show_wang_resources)
        layout.addWidget(self.wang_resource_button)
        self.supplemental_token_module_button=QPushButton('令/麦哲伦：召唤物模组端点对照')
        self.supplemental_token_module_button.setVisible(False)
        self.supplemental_token_module_button.clicked.connect(self.show_supplemental_token_modules)
        layout.addWidget(self.supplemental_token_module_button)
        self.charge_timeline_button=QPushButton('机械师S3：比较冲锋时刻与观察窗口')
        self.charge_timeline_button.setEnabled(False)
        self.charge_timeline_button.clicked.connect(self.show_charge_timeline)
        layout.addWidget(self.charge_timeline_button)
        self.shield_timeline_button=QPushButton('机械师S2：比较破屏与爆炸时刻')
        self.shield_timeline_button.setEnabled(False)
        self.shield_timeline_button.clicked.connect(self.show_shield_timeline)
        layout.addWidget(self.shield_timeline_button)
        self.healing_budget_button=QPushButton('测算逐友方有效治疗与生命预算')
        self.healing_budget_button.setEnabled(False)
        self.healing_budget_button.clicked.connect(self.show_healing_budget)
        layout.addWidget(self.healing_budget_button)
        self.skill_upgrade_button=QPushButton('比较技能等级升级收益（同培养）')
        self.skill_upgrade_button.setEnabled(False)
        self.skill_upgrade_button.clicked.connect(self.show_skill_upgrades)
        layout.addWidget(self.skill_upgrade_button)
        self.enemy_comparison_button=QPushButton('比较固定关卡敌人与难度条件')
        self.enemy_comparison_button.setEnabled(False)
        self.enemy_comparison_button.clicked.connect(self.show_enemy_comparison)
        layout.addWidget(self.enemy_comparison_button)
        self.scenario_library_button=QPushButton('保存与比较局外情景')
        self.scenario_library_button.setEnabled(False)
        self.scenario_library_button.clicked.connect(self.show_scenario_library)
        layout.addWidget(self.scenario_library_button)
        self.supplemental_skill_button=QPushButton('补充干员本局属性与单次技能对照')
        self.supplemental_skill_button.clicked.connect(self.show_supplemental_skills)
        layout.addWidget(self.supplemental_skill_button)
        self.damage_budget_button=QPushButton('测算逐敌人有效伤害与溢出')
        self.damage_budget_button.setEnabled(False)
        self.damage_budget_button.clicked.connect(self.show_damage_budget)
        layout.addWidget(self.damage_budget_button)
        self.cultivation_comparison_button=QPushButton('比较等级、信赖、潜能与模组培养方案')
        self.cultivation_comparison_button.clicked.connect(self.show_cultivation_comparison)
        layout.addWidget(self.cultivation_comparison_button)
        tools_layout=QGridLayout()
        for index,button in enumerate((self.token_comparison_button,self.token_budget_button,
                self.charge_timeline_button,self.shield_timeline_button,self.healing_budget_button,
                self.skill_upgrade_button,self.enemy_comparison_button,self.scenario_library_button,
                self.supplemental_skill_button,self.damage_budget_button,self.cultivation_comparison_button,
                self.wang_resource_button,self.supplemental_token_module_button)):
            layout.removeWidget(button);tools_layout.addWidget(button,index//2,index%2)
        layout.addLayout(tools_layout)
        self.damage_text = QPlainTextEdit()
        self.damage_text.setReadOnly(True)
        layout.addWidget(self.damage_text,1)
        self.raw_damage=QCheckBox('显示结构化计算数据（调试）')
        self.raw_damage.toggled.connect(self.render_damage)
        layout.addWidget(self.raw_damage)
        self.damage_technical=QCheckBox('显示技术资料（来源与原始字段说明）')
        self.damage_technical.toggled.connect(self.render_damage);layout.addWidget(self.damage_technical)
        label = QLabel('基础属性只读，只能调整等级进行模拟；精英、信赖、潜能、技能等级和模组来自读取。未确认时明确使用档案预览条件。回转和周期输出均为估计，模组条件机制/特训和部分藏品仍有缺失。')
        label.setWordWrap(True)
        layout.addWidget(label)
        self.deployment_elapsed.valueChanged.connect(lambda:self.calculate())
        self.healing_targets.valueChanged.connect(lambda:self.calculate())
        self.defense.valueChanged.connect(lambda:self.calculate())
        self.resistance.valueChanged.connect(lambda:self.calculate())
        self.charge_count.valueChanged.connect(lambda:self.calculate())
        self.shield_breaks.valueChanged.connect(lambda:self.calculate())
        self.shield_duration.valueChanged.connect(lambda:self.calculate())
        self.activation_count.valueChanged.connect(lambda:self.calculate())
        self.companion_attack.valueChanged.connect(lambda:self.calculate())
        self.stacks.valueChanged.connect(lambda:self.calculate())
        self.cooperative.toggled.connect(lambda:self.calculate())
        self.fragile.toggled.connect(lambda:self.calculate())
        self.shield_duration_known.toggled.connect(lambda:self.calculate())
        return tab

    def update_target_enemies(self):
        sid=self.target_stage.currentData()
        previous=self.target_enemy.currentData()
        self.target_enemy.blockSignals(True)
        self.target_enemy_choices.set_groups(enemy_groups((stage_previews().get(sid) or {}).get('possible_enemies',[]),
                   lambda e:{'stage_id':sid,'enemy_id':e['id'],'level':e['level']}),
                   emit=False)
        index=next((i for i in range(self.target_enemy.count()) if self.target_enemy.itemData(i)==previous),0)
        self.target_enemy.setCurrentIndex(index)
        self.target_enemy.blockSignals(False)
        self.update_enemy_context()
        if hasattr(self,'battle_preview'):self.battle_preview.set_stage(sid)
        if hasattr(self,'offline_tools'):self.offline_tools.set_stage(sid)

    def show_catalog_battle(self,sid):
        self.select_battle_stage(sid)
        self.battle_preview.set_stage(sid)
        self.centralWidget().setCurrentWidget(self.battle_preview)

    def show_catalog_map_node(self,node_id,binding):
        """Navigate the assistant only, rejecting stale run/template/position links."""
        graph=self.map_view.graph or {}
        node=next((n for n in graph.get('nodes',[]) if n['id']==node_id),None)
        valid=(isinstance(binding,dict) and isinstance(binding.get('epoch'),str) and bool(binding['epoch'])
            and binding['epoch']==self.run.state['id']
            and binding.get('zone_id')==graph.get('zone_id') and binding.get('template_id')==graph.get('template_id')
            and binding.get('node_id')==node_id and node is not None
            and type(binding.get('row')) is int and type(binding.get('col')) is int
            and binding['row']==node['row'] and binding['col']==node['col'])
        if not valid:
            self.node_catalog.status.setText('节点链接已过期或位置不符；请使用本局当前地图记录。');return
        self.map_view.select_node(node_id)
        self.centralWidget().setCurrentWidget(self.exploration_map_tab)

    def select_battle_stage(self,sid):
        self.target_stage_choices.select_value(sid)

    def recruited_operator_ids(self):
        return tuple(key for key,member in self.run.state['operators'].items()
                     if key in operator_profiles() and active_record(member,'present') and member.get('scope')!='account')

    def refresh_operator_overview(self):
        return self.operator_choices.set_overview(self.recruited_operator_ids(),emit=False)

    def show_fruit_marker_flow(self):
        from .fruit_marker_view import FruitMarkerPanel
        if self.fruit_marker_dialog is None:
            self.fruit_marker_dialog=FruitMarkerPanel(self)
            self.fruit_marker_dialog.nodePreviewRequested.connect(self.show_fruit_marker_declaration)
        self.fruit_marker_dialog.show()

    def show_fruit_marker_declaration(self,reference):
        # The marker tool owns a declared identity, without a verified map epoch.
        self.map_detail.setPlainText('局外声明节点引用\n地图：'+str(reference.get('map_id'))+
            '\n节点：'+str(reference.get('node_id'))+'\n实际地图绑定未核实；此引用不改变地图选择或本局状态。')
        self.centralWidget().setCurrentWidget(self.exploration_map_tab)

    def show_movement_sources(self):
        from .movement_source_view import MovementSourcePanel
        if self.movement_source_dialog is None:
            self.movement_source_dialog=MovementSourcePanel(self)
            self.movement_source_dialog.mapNodeSelected.connect(self.show_catalog_map_node)
            self.movement_source_dialog.catalogEventSelected.connect(self.show_source_catalog_event)
        cached=self.node_catalog.map_context
        live=bool(cached and not cached[3])
        self.movement_source_dialog.set_map_context(cached[0] if live else None,
            context=self.node_catalog.runtime_context if live else {},epoch=self.run.state['id'])
        self.movement_source_dialog.show()

    def show_source_catalog_event(self,event_id):
        panel=self.node_catalog;panel.show_directory()
        panel.kind.setCurrentIndex(panel.kind.findData('event'))
        panel.floor.setCurrentIndex(0);panel.node_type.setCurrentIndex(0);panel.search.clear();panel.refresh()
        row=next((i for i,e in enumerate(panel.entries) if e['kind']=='event' and e['record']['id']==event_id),None)
        if row is not None:
            panel.list.setCurrentRow(row);self.centralWidget().setCurrentWidget(panel)

    def select_operator(self,op):
        return self.operator_choices.select_value(op)

    def update_enemy_context(self):
        if not hasattr(self,'orb_mode'):return
        target=self.target_enemy.currentData() or {}
        enemy=next((e for e in (stage_previews().get(target.get('stage_id')) or {}).get('possible_enemies',[])
                    if e['id']==target.get('enemy_id') and e['level']==target.get('level')),None)
        self.target_enemy_picture.set_subject('enemy',target.get('enemy_id'),
            enemy['name']+' · '+ENEMY_TIERS.get(enemy['level_type'],'类别未确认') if enemy else '')
        self.damage_form.setRowVisible(self.target_enemy_picture,bool(enemy))
        if hasattr(self,'resistance'):
            self.damage_form.setRowVisible(self.defense,not enemy)
            self.damage_form.setRowVisible(self.resistance,not enemy)
        key=(target.get('stage_id'),target.get('enemy_id'),target.get('level'))
        if key!=self.displayed_enemy_context:
            self.orb_mode.blockSignals(True);self.orb_mode.setCurrentIndex(0);self.orb_mode.blockSignals(False)
            self.displayed_enemy_context=key
        self.damage_form.setRowVisible(self.orb_mode,target.get('enemy_id')=='enemy_2148_shorbb')
        if hasattr(self,'raw_damage'):self.calculate()

    def show_charge_timeline(self):
        if not self.damage_result:return
        scenario=self.damage_result['scenario']
        if scenario['operator']!='mechanist' or scenario['skill']!=3:return
        from .charge_timeline_view import ChargeTimelineDialog
        previous=getattr(self,'charge_timeline_dialog',None)
        if previous is not None:previous.close();previous.deleteLater()
        dialog=ChargeTimelineDialog(scenario,self.damage_result['result']['estimate']['skill']['duration_seconds'],self)
        self.charge_timeline_dialog=dialog;dialog.show()

    def show_cultivation_comparison(self):
        from .catalog import operator_profiles
        from .cultivation_comparison import compare_cultivation,format_cultivation
        from .reference_dialog import ReferenceDialog
        from copy import deepcopy
        identity=self.operator.currentData();profile=operator_profiles()[identity]
        scenario=deepcopy(self.damage_result['scenario']) if getattr(self,'damage_result',None) else {
            'operator':identity,'skill':self.skill.currentData() or 1,'skill_rank':7,
            'enemy_defense':self.defense.value(),'enemy_resistance':self.resistance.value()}
        elite=scenario.get('elite',len(profile['phases'])-1)
        proposal={'name':'当前预览基准','elite':elite,'level':scenario.get('level') or profile['phases'][elite]['max_level'],
            'trust':scenario.get('trust',100),'potential':scenario.get('potential',1),
            'module_id':scenario.get('module_id'),'module_level':scenario.get('module_level',0)}
        previous=getattr(self,'cultivation_comparison_dialog',None)
        if previous:previous.close()
        self.cultivation_comparison_dialog=ReferenceDialog('培养方案 · 属性与技能收益',
            '独立培养方案；第一项为差值基准，可添加不同等级、信赖、潜能和模组的完整方案。',
            {'proposals':[proposal]},lambda preview:compare_cultivation(scenario,preview),format_cultivation,
            [('name','方案'),('status','状态'),('attack','基础攻击'),('delta_attack','攻击差'),
             ('hp','基础生命'),('delta_hp','生命差'),('defense','基础防御'),
             ('window_damage','窗口伤害'),('delta_window_damage','伤害差')],self)
        self.cultivation_comparison_dialog.show()

    def show_damage_budget(self):
        if not getattr(self,'damage_result',None):return
        from .damage_budget import damage_sources,damage_budget,format_damage_budget
        from .reference_dialog import ReferenceDialog
        from copy import deepcopy
        scenario=deepcopy(self.damage_result['scenario']);sources=damage_sources(self.damage_result['result'])
        if not sources:return
        previous=getattr(self,'damage_budget_dialog',None)
        if previous:previous.close()
        self.damage_budget_dialog=ReferenceDialog('逐敌人伤害 · 声明生命预算',
            '手动声明目标与事件；预算耗尽不代表实际击杀。可选source：'+ '；'.join(s['id']+'（'+s['name']+'）' for s in sources),
            {'targets':[{'id':'目标甲','hp':10000,'defense':scenario.get('enemy_defense',0),'resistance':scenario.get('enemy_resistance',0)}],
             'events':[{'at_seconds':0,'target':'目标甲','source':sources[0]['id']}]},
            lambda preview:damage_budget(scenario,preview),format_damage_budget,
            [('at_seconds','声明秒数'),('target','目标'),('source','分项'),('per_hit','潜在伤害'),
             ('effective_damage','有效伤害'),('overkill','溢出'),('hp_after','剩余预算')],self)
        self.damage_budget_dialog.show()

    def show_supplemental_skills(self):
        from .supplemental_skills import defaults,supplemental_profiles
        from .supplemental_run_view import SupplementalRunDialog
        profiles=supplemental_profiles()['operators'];identity=self.operator.currentData()
        if identity not in profiles:identity=next(iter(profiles))
        previous=getattr(self,'supplemental_skill_dialog',None)
        if previous:previous.close()
        preview=defaults(identity)
        if identity==self.operator.currentData():
            conditions=self.training_conditions()
            preview.update({key:conditions[key] for key in ('elite','level','trust','potential')})
            from .skill_cultivation import select_rank
            preview['skill_rank']=select_rank(operator_profiles()[identity],1,conditions['elite'],
                state=self.current_operator_state(),account=self.account_cache.view(identity))['rank']
            preview.update(enemy_defense=self.defense.value(),enemy_resistance=self.resistance.value())
        self.supplemental_skill_dialog=SupplementalRunDialog(preview,self.supplemental_run_environment,self)
        self.supplemental_skill_dialog.show()

    def supplemental_run_environment(self):
        from copy import deepcopy
        from .supplemental_skills import supplemental_profiles
        from .training_view import run_operator_metadata
        ids=(self.run.held_relic_ids() if self.auto_relics.isChecked() else
             [self.relic_list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.relic_list.count())
              if self.relic_list.item(i).checkState()==Qt.CheckState.Checked])
        resources=self.run.calculation_resources()
        context={key:record['value'] for key,record in resources.items() if 'value' in record}
        parts=resources.get('parts_count',{})
        if type(parts.get('capacity')) is int and type(parts.get('value')) is int:
            context['empty_slots']=parts['capacity']-parts['value']
        metadata={}
        for identity in supplemental_profiles()['operators']:
            member=run_operator_metadata(self.run.state['operators'].get(identity),enabled=self.use_run_training.isChecked())
            metadata[identity]={key:member[key] for key in ('recruitment_kind','char_buff_ids','char_buffs_complete',
                               'char_buff_absent_ids','char_buff_pending_ids') if key in member}
        return deepcopy({'relic_ids':ids,'run_config':self.run.state.get('config',{}),'relic_context':context,
            'inventory_status':self.run.inventory_status() if self.auto_relics.isChecked() else
                {'source':'manual_test','complete':True,'recognized':len(ids),'expected_count':None},
            'operator_metadata':metadata})

    def show_scenario_library(self):
        if not self.damage_result:return
        from .scenario_library_view import ScenarioLibraryDialog
        previous=getattr(self,'scenario_library_dialog',None)
        if previous is not None:previous.close();previous.deleteLater()
        self.scenario_library_dialog=ScenarioLibraryDialog(self.damage_result['scenario'],
            Path(OPERATOR_STATE).with_name('scenario-library.json'),self)
        self.scenario_library_dialog.show()

    def show_enemy_comparison(self):
        if not self.damage_result:return
        from .enemy_comparison_view import EnemyComparisonDialog
        previous=getattr(self,'enemy_comparison_dialog',None)
        if previous is not None:previous.close();previous.deleteLater()
        self.enemy_comparison_dialog=EnemyComparisonDialog(self.damage_result['scenario'],self)
        self.enemy_comparison_dialog.show()

    def show_skill_upgrades(self):
        if not self.damage_result:return
        from copy import deepcopy
        from .skill_upgrade_comparison import compare_skill_upgrades,format_skill_upgrades
        from .reference_dialog import ReferenceDialog
        scenario=deepcopy(self.damage_result['scenario'])
        previous=getattr(self,'skill_upgrade_dialog',None)
        if previous is not None:previous.close();previous.deleteLater()
        self.skill_upgrade_dialog=ReferenceDialog('技能等级 · 同培养收益对照',
            '选择要比较的公共等级1–7或专精8–10。只替换等级，账号和本局不变；不可测算的等级列出原因。',
            {'ranks':list(range(1,11))},lambda preview:compare_skill_upgrades(scenario,preview),format_skill_upgrades,
            [('label','等级'),('status','测算状态'),('duration_parameter','持续参数/秒'),('sp_cost_parameter','技力参数'),
             ('window_damage','窗口总伤'),('delta_window_damage','相对基准伤害'),('window_healing','窗口治疗'),('delta_window_healing','相对基准治疗')],self)
        self.skill_upgrade_dialog.show()

    def show_healing_budget(self):
        if not self.damage_result:return
        from copy import deepcopy
        from .healing_budget import healing_sources,healing_budget,format_healing_budget
        from .reference_dialog import ReferenceDialog
        scenario=deepcopy(self.damage_result['scenario'])
        sources=healing_sources(self.damage_result['result'])
        if not sources:return
        previous=getattr(self,'healing_budget_dialog',None)
        if previous is not None:previous.close();previous.deleteLater()
        self.healing_budget_dialog=ReferenceDialog('逐友方有效治疗 · 局外生命预算',
            '下方友方生命是可修改的示例。events填写治疗heal（source选下方来源ID）或生命减少loss（amount填写减少量）；同刻按输入顺序。',
            {'recipients':[{'id':'示例友方','max_hp':3000,'hp':1000}],'events':[]},
            lambda preview:healing_budget(scenario,preview),format_healing_budget,
            [('at_seconds','声明秒数'),('recipient','友方'),('kind','事件'),('hp_before','此前生命'),
             ('amount_reference','单次量'),('effective_healing','有效治疗'),('overhealing','过量治疗'),('hp_after','之后生命')],self)
        self.healing_budget_dialog.show()

    def show_shield_timeline(self):
        if not self.damage_result:return
        from copy import deepcopy
        from .reference_dialog import ReferenceDialog
        from .shield_timeline import compare_shield_windows,format_shield_windows
        scenario=deepcopy(self.damage_result['scenario'])
        if scenario['operator']!='mechanist' or scenario['skill']!=2:return
        previous=getattr(self,'shield_timeline_dialog',None)
        if previous is not None:previous.close();previous.deleteLater()
        self.shield_timeline_dialog=ReferenceDialog('机械师S2 · 破屏与爆炸时刻',
            'source填owner（本体）或structure（结构体）；破屏与命中分别填写秒数。hit_seconds可为null。原表弹药不决定事件次数或结束时刻。',
            {'events':[],'windows_seconds':[0,5,20]},lambda preview:compare_shield_windows(scenario,preview),
            format_shield_windows,[('window_seconds','窗口/秒'),('declared_breaks','破屏'),('owner_hits','本体命中'),
                ('structure_hits','结构命中'),('explosion_damage_reference','爆炸条件伤害'),
                ('ordinary_damage_reference','普通攻击参考'),('conditional_damage_subtotal','条件小计')],self)
        self.shield_timeline_dialog.show()

    def show_token_budget(self):
        op=self.operator.currentData()
        if op not in catalog()['operators'] or not catalog()['operators'][op].get('tokens'):
            self.show_damage_text('当前干员没有已接入的独立召唤物配额资料。');return
        from .token_budget_view import TokenBudgetDialog
        previous=getattr(self,'token_budget_dialog',None)
        if previous is not None:previous.close();previous.deleteLater()
        self.token_budget_dialog=TokenBudgetDialog(op,self.training_conditions(),self)
        self.token_budget_dialog.show()

    def show_supplemental_token_modules(self):
        owner=self.operator.currentData()
        if owner not in ('char_2023_ling','char_248_mgllan'):return
        from .p2_supplemental_token_module_view import SupplementalTokenModuleDialog
        previous=getattr(self,'supplemental_token_module_dialog',None)
        if previous:previous.close()
        self.supplemental_token_module_dialog=SupplementalTokenModuleDialog(owner,self.training_conditions(),self)
        self.supplemental_token_module_dialog.show()

    def show_wang_resources(self):
        if self.operator.currentData()!='char_2027_wang' or self.skill.currentData() not in (1,2):
            self.show_damage_text('分池资源链仅覆盖望S1/S2的固定来源；其它来源保持未知。');return
        from .p2_wang_resource_view import WangResourceLedgerDialog
        previous=getattr(self,'wang_resource_dialog',None)
        if previous is not None:previous.close();previous.deleteLater()
        self.wang_resource_dialog=WangResourceLedgerDialog(self.training_conditions(),self,
            skill=self.skill.currentData(),rank=self.skill_rank_value())
        self.wang_resource_dialog.show()

    def show_token_module_comparison(self):
        from .token_module_comparison import compare_token_module
        op=self.operator.currentData();profile=catalog()['operators'][op]
        if not profile.get('tokens'):return
        training=self.training_conditions()
        previous=getattr(self,'token_comparison_dialog',None)
        if previous is not None:previous.close();previous.deleteLater()
        dialog=QDialog(self);dialog.setWindowTitle('召唤物模组升级参考（局外对照）')
        dialog.resize(950,600);layout=QVBoxLayout(dialog)
        label=QLabel(profile['name']+' · 同一培养条件：精英'+str(training['elite'])+' / 等级'+str(training['level'])+'。所选模组仅作升级模拟，不改变账号培养或本局记录。')
        label.setWordWrap(True);layout.addWidget(label)
        selector=QComboBox();selector.addItem('仅查看独立实体培养基础',None)
        for module in profile['modules']:selector.addItem(module['name']+'（模拟升级）',module['id'])
        layout.addWidget(selector)
        table=QTableWidget();table.setColumnCount(6)
        table.setHorizontalHeaderLabels(['独立实体 / 参数','无模组基础','模组1级','模组2级','模组3级','范围'])
        table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers);layout.addWidget(table)
        notice=QLabel();notice.setWordWrap(True);layout.addWidget(notice)
        def refresh():
            try:result=compare_token_module(op,training,selector.currentData())
            except (ValueError,KeyError) as error:
                table.setRowCount(0);notice.setText(str(error));dialog.comparison_result=None;return
            dialog.comparison_result=result;fields=(('hp','生命'),('attack','攻击'),('defense','防御'),
                ('resistance','法抗'),('deployment_cost','部署费用'),('interval','基础攻击间隔/秒'),
                ('held_limit','库存上限'),('concurrent_limit','每类在场上限'))
            table.setRowCount(len(result['tokens'])*len(fields))
            row=0
            for token in result['tokens']:
                for key,title in fields:
                    table.setItem(row,0,QTableWidgetItem(token['name']+' / '+title))
                    for column in range(1,5):
                        stage=next((s for s in token['stages'] if s['module_level']==column-1),None)
                        value=stage['values'].get(key) if stage else None
                        text=(format(value,'.6g') if value is not None else '未解锁' if stage and stage['state']=='locked' else '未确认' if stage else '未选择')
                        if stage and key in stage['differences']:text+=' ('+format(stage['differences'][key],'+.6g')+')'
                        table.setItem(row,column,QTableWidgetItem(text))
                    table.setItem(row,5,QTableWidgetItem('已核验片段；实际在场未知' if key in ('held_limit','concurrent_limit') else '独立培养 / 已核验模组片段'))
                    row+=1
            table.resizeColumnsToContents();notice.setText('\n'.join(result['notes']))
        selector.currentIndexChanged.connect(refresh)
        chosen=selector.findData(training.get('module_id'))
        if chosen<=0 and profile['modules']:chosen=1
        selector.setCurrentIndex(max(0,chosen));refresh()
        dialog.module_selector=selector;dialog.comparison_table=table
        self.token_comparison_dialog=dialog;dialog.show()

    def current_operator_state(self,*,preserve_level=None):
        from .training_view import select_training_view
        op=self.operator.currentData()
        account=self.account_cache.view(op)
        member=self.run.state['operators'].get(op) if self.use_run_training.isChecked() else None
        preserve=self.level_override if preserve_level is None else preserve_level
        result=select_training_view(op,account,member,operator_profiles(),catalog()['operators'],
                                   use_record_level=not preserve)
        self.training_view_notice=result['notice']
        return result['state']

    def current_run_operator_state(self):
        from .training_view import run_operator_metadata
        op=self.operator.currentData()
        member=self.run.state['operators'].get(op)
        return run_operator_metadata(member,enabled=self.use_run_training.isChecked())

    def account_training_status(self,text):
        op=self.operator.currentData()
        state=self.current_operator_state()
        confirmed=bool(state and state.get('scope')=='run')
        notice=self.account_cache.notice(op,run_confirmed=confirmed)
        view_notice=self.training_view_notice
        if view_notice:notice += ('\n' if notice else '')+view_notice
        self.training_status.setText(text+('\n'+notice if notice else ''))

    def training_conditions(self):
        op=self.operator.currentData()
        fields=self.current_operator_state().get('fields',{})
        elite=fields.get('elite',len(operator_profiles()[op]['phases'])-1)
        return {'elite':elite,'level':self.level.value(),'trust':fields.get('trust',100),
                'potential':fields.get('potential',1),'module_id':fields.get('module_id'),
                'module_level':fields.get('module_level',0)}

    def skill_rank_selection(self):
        from .skill_cultivation import select_rank
        op=self.operator.currentData()
        profile=operator_profiles().get(op)
        state=self.current_operator_state()
        elite=state.get('fields',{}).get('elite',len(profile['phases'])-1 if profile else 2)
        return select_rank(profile,self.skill.currentData(),elite,state=state,
            account=self.account_cache.view(op),
            account_reference=(hasattr(self,'account_skill_reference') and self.account_skill_reference.isChecked()),
            run_common_reference=(hasattr(self,'run_common_skill_reference') and self.run_common_skill_reference.isChecked()),
            level=self.level.value())

    def skill_rank_value(self):
        return self.skill_rank_selection()['rank']

    def clear_skill_rank_reference(self):
        self.account_skill_reference_key=None
        if hasattr(self,'account_skill_reference'):
            self.account_skill_reference.blockSignals(True)
            self.account_skill_reference.setChecked(False)
            self.account_skill_reference.blockSignals(False)
        if hasattr(self,'run_common_skill_reference'):
            self.run_common_skill_reference.blockSignals(True)
            self.run_common_skill_reference.setChecked(False)
            self.run_common_skill_reference.blockSignals(False)

    def update_skill_rank_source(self):
        if not hasattr(self,'skill_cultivation_explanation'):return
        from .skill_cultivation import explanation,format_explanation
        op,skill=self.operator.currentData(),self.skill.currentData()
        key=(op,skill)
        if key!=self.account_skill_reference_key:
            self.clear_skill_rank_reference()
            self.account_skill_reference_key=key
        selection=self.skill_rank_selection()
        self.account_skill_reference.setEnabled(selection['account_usable'])
        if not selection['account_usable'] and self.account_skill_reference.isChecked():
            self.account_skill_reference.blockSignals(True)
            self.account_skill_reference.setChecked(False)
            self.account_skill_reference.blockSignals(False)
            selection=self.skill_rank_selection()
        self.account_skill_reference.setToolTip(selection['account_reason'] or
            '明确选择该技能已读账号等级作局外模拟；不会标作本局读取，不改写账号或本局记录。')
        usable=selection.get('common_reference_usable',False) and not self.account_skill_reference.isChecked()
        if not usable and self.run_common_skill_reference.isChecked():
            self.run_common_skill_reference.blockSignals(True)
            self.run_common_skill_reference.setChecked(False)
            self.run_common_skill_reference.blockSignals(False)
            selection=self.skill_rank_selection()
        self.run_common_skill_reference.setEnabled(usable)
        self.damage_form.setRowVisible(self.run_common_skill_reference,selection.get('common_reference_usable',False))
        common=selection.get('common_reference',{})
        self.run_common_skill_reference.setToolTip(common.get('reason') or
            '仅对精英0/1本局已确认形态采用其它已开放技能的同一公共等级来源；该技能未直接读取，不传递专精，不补账号或招募上限，不改写本局。')
        profile=operator_profiles().get(op)
        state=self.current_operator_state()
        elite=state.get('fields',{}).get('elite',len(profile['phases'])-1 if profile else 2)
        row=explanation(op,profile,skill,elite,selection)
        self.skill_cultivation_row=row
        self.skill_cultivation_explanation.setText(format_explanation(row))
        self.damage_form.setRowVisible(self.skill_cultivation_explanation,row is not None)

    def update_operator(self,*,preserve_level=False):
        if not hasattr(self,'attack'):
            return
        op = self.operator.currentData()
        if hasattr(self,'token_comparison_button'):
            self.token_comparison_button.setEnabled(bool(catalog()['operators'].get(op,{}).get('tokens')))
        if op is None:
            self.display_operator=None;self.skill_override=False;self.level_override=False
            self.operator_picture.set_subject(None,None,'');self.level.setEnabled(False)
            self.skill.blockSignals(True);self.skill.clear();self.skill.blockSignals(False)
            for widget in (self.elite,self.trust,self.potential,self.module):widget.setText('未选择干员')
            self.account_training_status('总览只显示本局已确认招募的干员；可选职业分支进行局外预览。')
            self.update_skill_options()
            return
        self.level.setEnabled(True)
        state=self.current_operator_state(preserve_level=preserve_level)
        fields=state.get('fields',{})
        profile=operator_profiles()[op]
        self.operator_picture.set_subject('operator',op,profile['name']+' · '+PROFESSIONS[profile['profession']])
        elite=fields.get('elite',len(profile['phases'])-1)
        maximum=profile['phases'][elite]['max_level']
        if self.display_operator!=op:self.skill_override=False
        self.display_operator=op
        self.level.blockSignals(True)
        self.level.setMaximum(maximum)
        if not preserve_level:self.level.setValue(fields.get('level',maximum))
        self.level.blockSignals(False)
        self.level_override=preserve_level
        previous=self.skill.currentData()
        self.skill.blockSignals(True)
        self.skill.clear()
        choices=[i+1 for i,s in enumerate(profile['skills']) if s.get('unlock_elite',i)<=elite]
        for skill in choices:
            name = profile['skills'][skill-1]['levels'][-1]['name']
            self.skill.addItem(skill_icon(profile['skills'][skill-1]['id']),f'S{skill} · {name}',skill)
        preferred=fields.get('selected_skill',{'kaltsit':2,'silverash':3,'mechanist':1}.get(op,1))
        if self.skill_override and previous in choices:preferred=previous
        if preferred in choices:self.skill.setCurrentIndex(choices.index(preferred))
        self.skill.blockSignals(False)
        self.elite.setText(f'精英 {fields["elite"]}' if 'elite' in fields else f'未确认（档案预览：精英 {elite}）')
        self.trust.setText(f'{fields.get("trust_display",fields.get("trust"))}%（读取）' if 'trust' in fields else '未确认（档案预览：满信赖加成）')
        self.potential.setText(str(fields['potential']) if 'potential' in fields else '未确认（档案预览：潜能 1）')
        if 'module_id' not in fields:self.module.setText('未确认（档案预览：未计模组）')
        elif fields['module_id'] is None:self.module.setText('未装备模组' if profile['modules'] else '此数据档案无可装备模组')
        else:
            module=next((m for m in profile['modules'] if m['id']==fields['module_id']),None)
            self.module.setText(f'{module["name"] if module else "未知模组"} · 阶段 {fields.get("module_level","未确认")}')
        stamp=time.strftime('%H:%M:%S',time.localtime(state.get('captured_at',0))) if state else '尚未读取'
        if state.get('scope')=='run':
            confirmed=set(state['run_confirmed_fields'])
            for key,widget in [('elite',self.elite),('trust',self.trust),('potential',self.potential),('module_id',self.module)]:
                if key in fields and key not in confirmed:widget.setText(widget.text()+'（账号档案参考，本局未确认）')
            status='使用本局已确认培养记录，最后读取：'+stamp+'；切页后保留。缺失项使用标注的账号参考/预览条件。'
            if state.get('recruitment_kind')=='emergency_hire':
                status+=' 来源：应急雇佣，仅一次作战。'
        else:status='档案最后读取：'+stamp+'；本局实际培养尚待核对。未确认字段使用明确标注的预览条件。'
        self.account_training_status(status)
        self.update_base_attack()
        self.update_skill_options()
        if hasattr(self,'raw_damage'):self.calculate()

    def level_changed(self):
        self.level_override=True
        self.update_base_attack()
        self.update_skill_options()

    def skill_changed(self):
        self.skill_override=True
        self.update_skill_options()

    def apply_operator_observation(self,operator,captured_at):
        if self.account_cache.observe(operator,captured_at):
            self.show_observed_operator(operator['id'])

    def show_observed_operator(self,op):
        """Follow a newly observed identity once; repeated frames keep manual browsing."""
        new_identity=op!=self.last_observed_operator
        self.last_observed_operator=op
        if op not in operator_profiles() or (self.operator.currentData()!=op and not new_identity):return False
        preserve=self.operator.currentData()==op and self.level_override
        self.operator_choices.select_value(op,emit=False)
        self.update_operator(preserve_level=preserve)
        return True

    def apply_run_observation(self,observed,captured_at):
        if not self.run.apply(observed,captured_at):return False
        self.refresh_operator_overview()
        self.run_summary.setText(self.run.summary())
        self.sync_run_config()
        self.sync_run_relics()
        selected=observed.get('selected_operator')
        if not selected or not self.show_observed_operator(selected):
            self.update_operator(preserve_level=self.level_override)
        return True

    def sync_run_config(self):
        if hasattr(self,'battle_preview'):self.battle_preview.set_context(self.run.state.get('config',{}))
        difficulty=self.run.state.get('config',{}).get('difficulty')
        from .run_config import difficulty_value
        grade=difficulty_value(difficulty)
        self.difficulty.setEnabled(grade is None)
        self.difficulty.setToolTip('自动读取本局保密等级；切换页面后保留最近确认值。' if grade is not None else
            '缓存中的保密等级尚未满足当前常规模式资格；原记录保留，此处仅为分析预设。' if difficulty else
            '尚未自动确认；此处仅为分析预设。')
        if grade is not None:
            index=self.difficulty.findData(grade)
            if index>=0:self.difficulty.setCurrentIndex(index)

    def sync_run_relics(self):
        if not hasattr(self,'relic_list'):return
        automatic=self.auto_relics.isChecked()
        self.relic_list.blockSignals(True)
        for i in range(self.relic_list.count()):
            item=self.relic_list.item(i)
            flags=item.flags()
            item.setFlags(flags&~Qt.ItemFlag.ItemIsUserCheckable if automatic else flags|Qt.ItemFlag.ItemIsUserCheckable)
            if automatic:
                item.setCheckState(Qt.CheckState.Checked if item.data(Qt.ItemDataRole.UserRole) in self.run.held_relic_ids() else Qt.CheckState.Unchecked)
        self.relic_list.blockSignals(False)
        if hasattr(self,'raw_damage'):self.calculate()

    def reset_run(self):
        self.sample_epoch += 1
        self.capture.discard_pending()
        self.run.reset()
        self.clear_skill_rank_reference()
        self.refresh_operator_overview()
        self.observation=None
        self.capture_operator_picture.set_subject(None,None,'')
        replace_text(self.operator_summary,'本局已重置，等待新的干员页面读取；账号档案仍保留。',preserve=False)
        self.preview.clear();self.preview.setText('本局尚未采样')
        replace_text(self.observed_text,'',preserve=False)
        self.capture_status.setText('已开始新局，等待新的页面采样；账号档案已保留。')
        self.update_sampling_status()
        self.target_stage.setToolTip('本局节点详情尚未确认；可手动选择关卡进行局外预览。')
        self.map_frame=None
        self.map_frames.clear()
        self.last_observed_operator=None;self.last_observed_stage=None
        self.target_stage.setCurrentIndex(0)
        self.target_enemy.setCurrentIndex(0)
        self.sync_run_config()
        self.relic_context_previews.clear()
        self.relic_context.blockSignals(True);self.relic_context.clear();self.relic_context.blockSignals(False)
        self.target_buff_previews.clear();self.target_preview_operator=None
        self.target_buff_test.blockSignals(True);self.target_buff_test.setChecked(False);self.target_buff_test.blockSignals(False)
        self.target_buff_list.blockSignals(True);self.target_buff_list.clear();self.target_buff_list.blockSignals(False)
        self.run_summary.setText(self.run.summary())
        self.sync_run_relics()
        self.update_operator()
        self.render_map()

    def update_base_attack(self):
        if not hasattr(self,'attack'):return
        from .catalog import operator_attributes
        values=operator_attributes(self.operator.currentData(),**self.training_conditions())
        self.attack.setText(f'{values["attack"]:g}（自动计算）')

    def update_skill_options(self):
        if not hasattr(self,'cooperative'):
            return
        op,skill = self.operator.currentData(), self.skill.currentData()
        profile=operator_profiles().get(op) or {'skills':[]}
        self.update_skill_rank_source()
        current=profile['skills'][skill-1]['levels'][self.skill_rank_value()-1] if skill else {}
        self.skill_picture.set_subject('skill',profile['skills'][skill-1]['id'],current['name']) if skill else self.skill_picture.set_subject(None,None,'')
        from .reporting import has_healing
        implemented=op in catalog()['operators']
        if hasattr(self,'wang_resource_button'):
            self.wang_resource_button.setVisible(op=='char_2027_wang' and skill in (1,2))
        if hasattr(self,'supplemental_token_module_button'):
            self.supplemental_token_module_button.setVisible(op in ('char_2023_ling','char_248_mgllan'))
        healer=implemented and has_healing(op,skill)
        conditions=[(self.deployment_elapsed,op=='silverash' and self.training_conditions()['elite']==2),
                    (self.healing_targets,healer),
                    (self.continuous_attacks,implemented and current.get('sp_type') in ('INCREASE_WHEN_ATTACK','INCREASE_WITH_TIME')),
                    (self.cooperative,op=='silverash' and skill==3),
                    (self.fragile,op=='silverash' and skill==3),
                    (self.charge_count,op=='mechanist' and skill==3),
                    (self.shield_breaks,op=='mechanist' and skill==2),
                    (self.barrier_ledger_button,op=='mechanist' and skill==2),
                    (self.shield_grant_button,op=='mechanist' and skill==2),
                    (self.shield_inventory_button,op=='mechanist' and skill==2),
                    (self.explosion_values_button,op=='mechanist' and skill==2),
                    (self.shield_duration,op=='mechanist' and skill==2),
                    *[(w,op=='silverash' and skill==2) for w in (self.activation_count,self.companion_attack,self.stacks)]]
        for widget,visible in conditions:self.damage_form.setRowVisible(widget,visible)
        for owner,key,skills,widget in self.model_option_widgets:
            visible=owner==op and skill in skills
            if key=='healing_target_hp_ratio':
                from .susuro_healing import selected_trait
                visible=visible and selected_trait(profile,{'operator':op,**self.training_conditions()}) is not None
            if key=='guardian_healing_target_hp_ratio':
                from .guardian_healing import selected_trait as selected_guardian_trait
                visible=visible and selected_guardian_trait(profile,{'operator':op,**self.training_conditions()}) is not None
            if owner=='mechanist' and key=='mechanist_module_static_reference':
                from .mechanist_module_reference import qualification
                visible=visible and qualification({'operator':op,'skill':skill,**self.training_conditions()})['qualified']
                widget.setToolTip('默认关闭。仅按已封存版本计算本体伤害包；在局外情景JSON声明当前目标由谁阻挡。实际阻挡、来源存续、碰撞和完整总量未知。一级原件只开放第一技能。')
            if owner=='char_133_mm' and key=='mei_module_static_reference':
                from .mei_module_static_reference import qualification
                visible=visible and qualification({'operator':op,'skill':skill,**self.training_conditions()})['qualified']
                widget.setToolTip('默认关闭。仅当前 MAR-X 精二40级及以上可选；局外 JSON 声明目标当前是否满足 FLY_ONLY。基础敌人飞行分类不代替当前状态，实际附着、攻击时钟与完整总量未知。')
            if owner=='char_4202_haruka' and key=='haruka_module_target_static_reference':
                from .haruka_target_static_reference import qualification
                visible=visible and qualification({'operator':op,'skill':skill,**self.training_conditions()})['qualified']
                widget.setToolTip('默认关闭。明确采用封存原件的满额潜在治疗人数和S2合成规则；沿用受疗人数声明，实际获取、回调和完整总量未知。')
            self.damage_form.setRowVisible(widget,visible)
            if owner==op=='char_110_deepcl' and key=='summon_count':
                from .summons import token_concurrent_limit
                cap=token_concurrent_limit(profile,{'operator':op,**self.training_conditions()},'token_10001_deepcl_tentac')
                widget.blockSignals(True)
                widget.setMaximum(cap if cap is not None else 4)
                widget.blockSignals(False)
                widget.setToolTip(f'当前培养/模组的触手在场上限：{cap if cap is not None else "未核验"}；仅作局外数量假设，仍受关卡部署位和库存约束。')
        self.update_condition_cultivation_explanations(op,skill)
        self.healing_targets.blockSignals(True)
        if op=='char_4202_haruka' and skill:
            from .haruka_healing_reference import conditional_input_limit
            limit=conditional_input_limit(profile,{'operator':op,**self.training_conditions(),
                'skill_rank':self.skill_rank_value()},current)
            tooltip='按当前培养和原表特性/技能参数声明满额潜在受疗数；可明确选择已封存BLS-Y静态组合参考，实际友方获取和完整总量未知。默认继续保留独立来源与额外组合份额。'
        else:
            limit=100 if (op=='char_1037_amiya3' and skill==1) or (op=='kaltsit' and skill==2) else (
                2 if (op=='char_2025_shu' and skill==2) or (op=='kaltsit' and skill==3) else 1)
            tooltip=''
        self.healing_targets.setMaximum(limit)
        self.healing_targets.setToolTip(tooltip)
        self.healing_targets.blockSignals(False)
        known=self.current_operator_state().get('skill_ranks',{})
        if skill is None:
            self.rank.setText('无可用技能')
            if hasattr(self,'raw_damage'):self.calculate()
            return
        from .skill_cultivation import rank_label
        self.rank.setText(rank_label(self.skill_rank_selection()))
        if hasattr(self,'raw_damage'):self.calculate()

    def update_condition_cultivation_explanations(self,op,skill):
        # Early construction callbacks may run before this presentation row exists.
        if not hasattr(self,'condition_cultivation_explanation'):return
        from .condition_cultivation import TARGET_OPERATORS,TARGET_FIELDS,explanations,format_explanation
        self.condition_cultivation_rows=[]
        self.condition_cultivation_explanation.setText('')
        self.damage_form.setRowVisible(self.condition_cultivation_explanation,False)
        if op not in TARGET_OPERATORS or not skill:return
        profile=catalog()['operators'].get(op)
        if profile is None:return
        values={key:widget.isChecked() if isinstance(widget,QCheckBox) else widget.value()
                for owner,key,skills,widget in self.model_option_widgets
                if owner==op and skill in skills and key in TARGET_FIELDS}
        rows=explanations(profile,{'operator':op,'skill':skill,**self.training_conditions()},
                          state=self.current_operator_state(),level_override=self.level_override,values=values)
        self.condition_cultivation_rows=rows
        text={row['field']:format_explanation(row) for row in rows}
        self.condition_cultivation_explanation.setText('\n\n'.join(text.values()))
        self.damage_form.setRowVisible(self.condition_cultivation_explanation,bool(rows))
        for owner,key,skills,widget in self.model_option_widgets:
            if owner==op and skill in skills and key in text:widget.setToolTip(text[key])

    def filter_relics(self, text):
        for i in range(self.relic_list.count()):
            item = self.relic_list.item(i)
            item.setHidden(text not in item.text())

    def sync_scenario_previews(self,op,skill):
        """Keep both temporary editors bound to an implemented owner/skill."""
        key=(op,skill) if op in catalog()['operators'] and skill is not None else None
        if key!=self.timing_preview_key:
            if self.timing_preview_key is not None:
                self.timing_previews[self.timing_preview_key]=self.timing_scenario.toPlainText()
                self.relic_context_previews[self.timing_preview_key]=self.relic_context.toPlainText()
            for widget,previews in ((self.timing_scenario,self.timing_previews),
                                    (self.relic_context,self.relic_context_previews)):
                blocked=widget.blockSignals(True)
                widget.setPlainText(previews.get(key,'') if key is not None else '')
                widget.blockSignals(blocked)
            self.timing_preview_key=key
        self.timing_scenario.setEnabled(key is not None)
        self.relic_context.setEnabled(key is not None)

    def calculate(self):
        if hasattr(self,'charge_timeline_button'):self.charge_timeline_button.setEnabled(False)
        if hasattr(self,'shield_timeline_button'):self.shield_timeline_button.setEnabled(False)
        if hasattr(self,'healing_budget_button'):self.healing_budget_button.setEnabled(False)
        if hasattr(self,'skill_upgrade_button'):self.skill_upgrade_button.setEnabled(False)
        if hasattr(self,'enemy_comparison_button'):self.enemy_comparison_button.setEnabled(False)
        if hasattr(self,'scenario_library_button'):self.scenario_library_button.setEnabled(False)
        if hasattr(self,'damage_budget_button'):self.damage_budget_button.setEnabled(False)
        self.damage_result=None
        if hasattr(self,'relic_context'):self.damage_form.setRowVisible(self.relic_context,False)
        op=self.operator.currentData()
        self.sync_animation_references(op,self.skill.currentData())
        if hasattr(self,'target_buff_list'):
            self.sync_target_buffs(op)
        self.sync_scenario_previews(op,self.skill.currentData())
        if op is None:
            self.show_damage_text('本局总览暂无已确认招募干员。请选择职业分支进行局外预览。')
            return
        if op not in catalog()['operators']:
            state=self.current_operator_state() or {'id':op,'fields':{},'skill_ranks':{}}
            text=format_operator_observation({**state,'id':op},self.training_conditions())
            if not state.get('fields'):text+='\n未读取培养状态，以上为明确的档案预览条件。'
            self.show_damage_text(text+'\n\n此干员可读取培养档案；技能伤害规则尚未实现，不将未知伤害显示为零。')
            return
        if self.skill.currentData() is None:
            self.show_damage_text('该精英阶段尚无已实现的技能，请选择已开放的计算档案。')
            return
        ids = [self.relic_list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.relic_list.count())
               if self.relic_list.item(i).checkState() == Qt.CheckState.Checked]
        scenario = {'operator':self.operator.currentData(),'skill':self.skill.currentData(),
            **self.training_conditions(),'deployment_elapsed_seconds':self.deployment_elapsed.value(),
            'healing_targets':self.healing_targets.value(),'continuous_attacks':self.continuous_attacks.isChecked(),
            'skill_rank':self.skill_rank_value(),
            'enemy_defense':self.defense.value(),'enemy_resistance':self.resistance.value(),
            'cooperative':self.cooperative.isChecked(),'preexisting_fragile':self.fragile.isChecked(),
            'charge_count':self.charge_count.value(),'shield_break_count':self.shield_breaks.value(),
            'activation_count':self.activation_count.value(),'companion_attack':self.companion_attack.value(),
            'deployment_stacks':self.stacks.value(),'relic_ids':ids}
        for owner,key,skills,widget in self.model_option_widgets:
            if owner==op and self.skill.currentData() in skills:
                if owner=='mechanist' and key=='mechanist_module_static_reference':
                    from .mechanist_module_reference import qualification
                    if not qualification(scenario)['qualified']:continue
                if owner=='char_133_mm' and key=='mei_module_static_reference':
                    from .mei_module_static_reference import qualification
                    if not qualification(scenario)['qualified']:continue
                if owner=='char_4202_haruka' and key=='haruka_module_target_static_reference':
                    from .haruka_target_static_reference import qualification
                    if not qualification(scenario)['qualified']:continue
                scenario[key]=widget.isChecked() if isinstance(widget,QCheckBox) else widget.value()
        state=self.current_operator_state()
        run_state=self.current_run_operator_state()
        scenario['recruitment_kind']=run_state.get('recruitment_kind') if run_state.get('scope')=='run' else None
        scenario['char_buff_ids']=run_state.get('char_buff_ids',[]) if run_state.get('scope')=='run' else []
        scenario['char_buffs_complete']=run_state.get('char_buffs_complete') is True if run_state.get('scope')=='run' else False
        scenario['char_buff_absent_ids']=list(run_state.get('char_buff_absent_ids',[])) if run_state.get('scope')=='run' else []
        scenario['char_buff_pending_ids']=list(run_state.get('char_buff_pending_ids',[])) if run_state.get('scope')=='run' else []
        if self.target_buff_test.isChecked():
            scenario['char_buff_ids']=list(dict.fromkeys(scenario['char_buff_ids']+[
                self.target_buff_list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.target_buff_list.count())
                if self.target_buff_list.item(i).checkState()==Qt.CheckState.Checked]))
            scenario['char_buff_absent_ids']=[bid for bid in scenario['char_buff_absent_ids'] if bid not in scenario['char_buff_ids']]
            scenario['char_buff_pending_ids']=[bid for bid in scenario['char_buff_pending_ids'] if bid not in scenario['char_buff_ids']]
        fields=state.get('fields',{})
        scenario['unconfirmed_training']=[label for key,label in [('elite','精英阶段'),('trust','信赖'),
            ('potential','潜能'),('module_id','模组'),('module_level','模组阶段')] if key not in fields]
        known_ranks=state.get('skill_ranks',{})
        if self.skill_rank_selection()['manual_reference_applied']:
            scenario['unconfirmed_training'].append('所选技能等级（已选账号参考，局外模拟）')
        elif self.skill_rank_selection().get('common_reference_applied'):
            scenario['unconfirmed_training'].append('所选技能等级（已选本局公共等级来源参考，未直接读取）')
        elif str(self.skill.currentData()) not in known_ranks and self.skill.currentData() not in known_ranks:
            scenario['unconfirmed_training'].append('所选技能等级')
        if 'level' not in fields and not self.level_override:scenario['unconfirmed_training'].append('当前等级')
        if fields and state.get('scope')!='run':
            scenario['unconfirmed_training'].append('本局实际培养（当前为干员详情档案）')
        if state.get('scope')=='run':
            confirmed=state['run_confirmed_fields']
            scenario['unconfirmed_training'] += [label+'（账号参考）' for key,label in
                [('level','本局等级'),('elite','本局精英阶段'),('trust','本局信赖'),('potential','本局潜能'),
                 ('module_id','本局模组'),('module_level','本局模组阶段')] if key in fields and key not in confirmed]
        scenario['inventory_status']=self.run.inventory_status() if self.auto_relics.isChecked() else {
            'source':'manual_test','complete':True,'recognized':len(ids),'expected_count':None}
        if self.auto_relics.isChecked():scenario['relic_history_context']=self.run.relic_history_context()
        scenario['run_config']=self.run.state.get('config',{})
        target=self.target_enemy.currentData()
        self.defense.setEnabled(target is None);self.resistance.setEnabled(target is None)
        if target:
            scenario['target_enemy']=dict(target)
            if target['enemy_id']=='enemy_2148_shorbb':scenario['target_enemy']['orb_mode']=self.orb_mode.currentData()
        if self.limit_window.isChecked():
            scenario['window_seconds'] = self.window_seconds.value()
        if self.operator.currentData()=='mechanist' and self.skill.currentData()==2 and self.shield_duration_known.isChecked():
            scenario['skill_duration_seconds']=self.shield_duration.value()
        try:
            profile=catalog()['operators'][op]
            needed=set()
            for rid in ids:
                for effect in active_effects(mechanics()['relics'][rid],rid):
                    if effect.get('target_enemy_id') and target and target['enemy_id']!=effect['target_enemy_id']:continue
                    if matches(effect,profile) or any(matches(effect,t,token=True) for t in profile.get('tokens',{}).values()):
                        if effect.get('condition') and effect['condition']!='emergency_hire':needed.add(effect['condition'])
                        if effect.get('recipient_condition'):needed.add(effect['recipient_condition'])
                        if effect.get('loss_pending_condition'):needed.add(effect['loss_pending_condition'])
                        if effect.get('unit_condition') and profile.get('tokens'):needed.add('token_conditions')
                        if effect.get('enemy_level'):needed.add('enemy_level_type')
            if op=='mechanist' and scenario.get('mechanist_module_static_reference'):
                needed.add('mechanist_target_blocker')
            if op=='char_133_mm' and scenario.get('mei_module_static_reference'):
                needed.add('mei_target_motion')
            self.damage_form.setRowVisible(self.relic_context,bool(needed))
            self.damage_form.labelForField(self.relic_context).setText('局外情景条件（测试）' if needed & {'mechanist_target_blocker','mei_target_motion'} else '当前藏品条件（测试）')
            examples={'mei_target_motion':'fly','mechanist_target_blocker':'own_token','gold':25,'parts_count':3,'empty_slots':4,'current_hp_ratio':.65,'deployed_casters':2,'adjacent_allies':1,
                'skill_cast_stacks':1,'altar_stacks':3,'chitin_recipient':1,'battle_start_shields':1,'blocked_enemies':1,
                'probe_stacks':2,'fire_rod_stacks':3,'deployment_hp_ratio':.65,'deployment_loss_unused':1,'enemy_level_type':'ELITE',
                'grudge_stacks':100,'deployed_seconds':80,'near_protection_point':1,'enemy_first_damage_unused':1,
                'entered_zone_count':2,'active_other_aura_sources':1,'mercenary_recipient':1,'mercenary_stacks':1,
                'token_conditions':{tid:{'blocked_enemies':1} for tid in profile.get('tokens',{})}}
            labels={'mechanist_target_blocker':'当前目标阻挡身份：self本体、own_token所属召唤物、other其他单位、none未阻挡、unknown未确认；不能用人数代替。此值仅来自手动局外声明。','parts_count':'当前零件箱实有零件数量（不是容量或估价）；悲伤的红计数上限99',
                'mei_target_motion':'fly声明当前目标满足原生FLY_ONLY；not_fly不满足；unknown未确认。只接受手动局外声明，不由敌人基础分类或浮空参数推断。',
                'altar_stacks':'圆石祭坛实际层数（非战斗次数，最多10）','chitin_recipient':'当前干员是否获得几丁质刺刃（0/1）',
                'battle_start_shields':'开战时的对局护盾值（不是屏障）','blocked_enemies':'本体实际阻挡敌人数（不是阻挡上限）',
                'probe_stacks':'探测先锋实际层数（最多99）','token_conditions':'各召唤物独立阻挡条件（不继承本体）'}
            labels.update(empty_slots='零件箱空栏数（容量减已持有数量，不能以零件数代替）',
                grudge_stacks='仇名录实际击杀叠层（独立乘算，最多999；不由战斗次数推断）',
                deployed_seconds='当前干员已在场秒数（局外条件，不读取实时站位）',
                near_protection_point='当前干员位于蓝色目标点周围八格（0/1，局外条件）',
                enemy_first_damage_unused='当前技能开始时，该干员对本目标的首次伤害尚未触发（0/1）',
                entered_zone_count='已累计进入的新区域计数（非当前主楼层；不能用楼层号替代）',
                active_other_aura_sources='犬植浆当前生效的其他干员光环数，已排除自身及阻挡失效条件（局外情景）',
                mercenary_recipient='当前干员是否为佣兵饰物的实际受益者（0/1）',
                mercenary_stacks='佣兵饰物当前总层数，包含初始1层，最多10层；不是额外完美作战次数',
                fire_rod_stacks='厄运火杆实际层数，0–99；不能由楼层或任意战斗胜利次数推断',
                deployment_hp_ratio='他缚本次部署损血事件前生命比例（0–1，独立局外参考，不读取实时生命）',
                deployment_loss_unused='本次部署他缚损血是否尚未触发（0/1）；重算不推进此状态，退场后新部署需重新确认情景')
            self.relic_context.setPlaceholderText('局外情景示例（不会自动套用）：'+json.dumps({k:examples.get(k,0) for k in sorted(needed)},ensure_ascii=False))
            self.relic_context.setToolTip('只使用当前适用藏品或已选模组参考的条件；留空保持未确认，测试值不写入本局记忆。\n'+
                '\n'.join(k+'：'+labels.get(k,'当前藏品所需的明确计算条件') for k in sorted(needed)))
            resources=self.run.calculation_resources()
            context={name:r['value'] for name,r in resources.items() if name in needed and name not in ('mechanist_target_blocker','mei_target_motion')}
            parts=resources.get('parts_count',{})
            if 'empty_slots' in needed and isinstance(parts.get('capacity'),int) and isinstance(parts.get('value'),int):
                context['empty_slots']=parts['capacity']-parts['value']
            if needed and self.relic_context.toPlainText().strip():
                preview=parse_preview_object(self.relic_context.toPlainText(),'藏品测试条件')
                context.update({k:v for k,v in preview.items() if k in needed})
            if 'enemy_level_type' in context:scenario['enemy_level_type']=context.pop('enemy_level_type')
            scenario['relic_context']=context
            scenario['relic_context_source']='本局最近确认的计数；测试条件仅用于预览'
            scenario['timing_mode']='frames' if self.frame_timing.isChecked() else 'continuous'
            if self.timing_scenario.toPlainText().strip():
                scenario['timing']=parse_preview_object(self.timing_scenario.toPlainText(),'战斗时序情景')
            if op=='char_1050_chen3' and self.chen_motion_orientation.currentData() is not None:
                scenario['chen_motion_orientation']=self.chen_motion_orientation.currentData()
            if self.frame_timing.isChecked():
                for field,widget in (('normal_animation_reference',self.normal_animation_reference),
                                     ('animation_reference',self.skill_animation_reference)):
                    if widget.currentData() is not None:
                        scenario.setdefault('timing',{})[field]=widget.currentData()
            result = calculate_damage(scenario)
            apply_relic_history_notice(scenario,result)
            if self.target_buff_test.isChecked():
                result['estimate']['notes'].insert(0,'当前启用个人强化测试；测试选项不代表从本局画面读取到的强化，也不写入记忆。')
            self.damage_result = {'scenario':scenario,'result':result}
            if hasattr(self,'offline_tools'):self.offline_tools.set_scenario(scenario)
            if hasattr(self,'paired_calibration'):self.paired_calibration.set_scenario(scenario)
            if hasattr(self,'attack_state_sequence'):self.attack_state_sequence.set_context(scenario)
            if hasattr(self,'timing_calibration'):self.timing_calibration.set_scenario(scenario)
            if hasattr(self,'bounded_calibration'):self.bounded_calibration.set_scenario(scenario)
            if hasattr(self,'calibration_experiment'):self.calibration_experiment.set_scenario(scenario)
            if hasattr(self,'recipient_native_ratio'):self.recipient_native_ratio.set_context(scenario)
            if hasattr(self,'relic_order_precision'):self.relic_order_precision.set_context(scenario)
            self.charge_timeline_button.setEnabled(op=='mechanist' and scenario['skill']==3)
            self.shield_timeline_button.setEnabled(op=='mechanist' and scenario['skill']==2)
            from .healing_budget import healing_sources
            self.healing_budget_button.setEnabled(bool(healing_sources(result)))
            self.skill_upgrade_button.setEnabled(True)
            self.enemy_comparison_button.setEnabled(True)
            self.scenario_library_button.setEnabled(True)
            from .damage_budget import damage_sources
            self.damage_budget_button.setEnabled(bool(damage_sources(result)))
            self.render_damage()
        except Exception as error:
            self.damage_result=None
            self.show_damage_text(str(error))

    def sync_animation_references(self,op,skill):
        key=(op,skill)
        widgets=(self.normal_animation_reference,self.skill_animation_reference)
        if key!=self.animation_preview_key:
            if self.animation_preview_key is not None:
                self.animation_previews[self.animation_preview_key]=[w.currentData() for w in widgets]
            saved=self.animation_previews.get(key,[None,None])
            for index,widget in enumerate(widgets):
                widget.blockSignals(True);widget.clear();widget.addItem('沿用现有参考（未绑定动作）',None)
                for record in animation_choices(op,skill,normal=index==0) if op and skill else []:
                    widget.addItem(animation_label(record),record['id'])
                found=widget.findData(saved[index]);widget.setCurrentIndex(max(0,found))
                widget.blockSignals(False)
            self.animation_preview_key=key
        for widget in widgets:
            self.damage_form.setRowVisible(widget,self.frame_timing.isChecked() and widget.count()>1)
        if key!=self.chen_motion_preview_key:
            if self.chen_motion_preview_key is not None:
                self.chen_motion_previews[self.chen_motion_preview_key]=self.chen_motion_orientation.currentData()
            self.chen_motion_orientation.blockSignals(True)
            found=self.chen_motion_orientation.findData(self.chen_motion_previews.get(key))
            self.chen_motion_orientation.setCurrentIndex(max(0,found))
            self.chen_motion_orientation.blockSignals(False)
            self.chen_motion_preview_key=key
        self.damage_form.setRowVisible(self.chen_motion_orientation,op=='char_1050_chen3' and skill in (1,2,3))

    def sync_target_buffs(self,op):
        if self.target_preview_operator!=op:
            if self.target_preview_operator is not None:
                self.target_buff_previews[self.target_preview_operator]=[
                    self.target_buff_list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.target_buff_list.count())
                    if self.target_buff_list.item(i).checkState()==Qt.CheckState.Checked]
            self.target_buff_list.blockSignals(True);self.target_buff_list.clear()
            profession=operator_profiles()[op]['profession'] if op in operator_profiles() else None
            for bid,buff in mechanics()['char_buffs'].items():
                active,_,pending,_=partition(buff,bid)
                if not profession or pending or not active:continue
                if buff['required_profession'] and profession not in buff['required_profession'].split('|'):continue
                item=QListWidgetItem(buff['name']);item.setData(Qt.ItemDataRole.UserRole,bid)
                item.setIcon(QIcon(str(ROOT/'rouge/data/relic-icons'/f'{buff["relic_id"]}.png')))
                item.setToolTip(buff['raw']['functionDesc']+'\n仅当前干员测试；未确认领取者时不自动套用。')
                item.setFlags(item.flags()|Qt.ItemFlag.ItemIsUserCheckable)
                item.setCheckState(Qt.CheckState.Checked if bid in self.target_buff_previews.get(op,[]) else Qt.CheckState.Unchecked)
                self.target_buff_list.addItem(item)
            self.target_buff_list.blockSignals(False);self.target_preview_operator=op
        self.damage_form.setRowVisible(self.target_buff_list,self.target_buff_test.isChecked() and self.target_buff_list.count()>0)
        from .run_metadata_view import format_run_buff_status
        self.target_buff_status.setText(format_run_buff_status(self.current_run_operator_state(),mechanics()['char_buffs']))

    def render_damage(self):
        if not self.damage_result:return
        if self.raw_damage.isChecked():
            self.show_damage_text(json.dumps(self.damage_result,ensure_ascii=False,indent=2))
        else:self.show_damage_text(format_report(self.damage_result['result'],technical=self.damage_technical.isChecked()))

    def show_damage_text(self,text):
        target=self.target_enemy.currentData() or {}
        key=(self.operator.currentData(),self.skill.currentData(),self.raw_damage.isChecked(),
             self.damage_technical.isChecked() if hasattr(self,'damage_technical') else False,
             self.target_stage.currentData(),target.get('enemy_id'),target.get('level'))
        replace_text(self.damage_text,text,preserve=self.damage_detail_key==key)
        self.damage_detail_key=key

    def make_chat_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        form = QFormLayout()
        self.mode = QComboBox()
        self.mode.addItems(['ChatGPT 客户端 · 后台管道','服务商 API · 备选'])
        form.addRow('连接方式',self.mode)
        self.desktop_threads = QComboBox()
        form.addRow('普通 ChatGPT 会话',self.desktop_threads)
        desktop_buttons=QHBoxLayout()
        self.desktop_refresh=QPushButton('刷新会话')
        self.desktop_refresh.clicked.connect(lambda:self.desktop_request('refresh'))
        desktop_buttons.addWidget(self.desktop_refresh)
        self.desktop_bind=QPushButton('绑定所选会话')
        self.desktop_bind.clicked.connect(self.bind_desktop)
        desktop_buttons.addWidget(self.desktop_bind)
        self.desktop_read=QPushButton('刷新回复 / 确认送达')
        self.desktop_read.clicked.connect(lambda:self.desktop_request('read'))
        desktop_buttons.addWidget(self.desktop_read)
        layout.addLayout(desktop_buttons)
        self.profile = QLineEdit('default')
        form.addRow('配置名称 / 凭据名',self.profile)
        self.base_url = QLineEdit('https://api.deepseek.com')
        form.addRow('API 基础地址',self.base_url)
        self.protocol = QComboBox()
        self.protocol.addItem('Chat Completions','chat_completions')
        self.protocol.addItem('Responses','responses')
        form.addRow('API 协议',self.protocol)
        self.model = QLineEdit()
        self.model.setPlaceholderText('填写服务商提供的模型标识')
        form.addRow('模型',self.model)
        self.key = QLineEdit()
        self.key.setEchoMode(QLineEdit.EchoMode.Password)
        self.key.setPlaceholderText('本次使用；保存后从 Windows 凭据管理器读取')
        form.addRow('API Key',self.key)
        self.context = QCheckBox('发送最新观测、难度/结局预设和本地伤害结果（不上传游戏画面）')
        self.context.setChecked(True)
        form.addRow(self.context)
        layout.addLayout(form)
        buttons = QHBoxLayout()
        save = QPushButton('保存配置与凭据')
        save.clicked.connect(self.save_settings)
        buttons.addWidget(save)
        clear = QPushButton('清空本地聊天')
        clear.clicked.connect(self.clear_chat)
        buttons.addWidget(clear)
        layout.addLayout(buttons)
        self.chat_status = QLabel('点击刷新会话，选择普通 ChatGPT 聊天后绑定；无需 API Key。')
        self.chat_status.setWordWrap(True)
        layout.addWidget(self.chat_status)
        self.transcript = QPlainTextEdit()
        self.transcript.setReadOnly(True)
        layout.addWidget(self.transcript,1)
        self.question = QPlainTextEdit()
        self.question.setPlaceholderText('输入问题')
        self.question.setMaximumHeight(110)
        layout.addWidget(self.question)
        buttons = QHBoxLayout()
        self.send_button = QPushButton('发送')
        self.send_button.clicked.connect(self.send_chat)
        buttons.addWidget(self.send_button)
        cancel = QPushButton('取消等待 / 后续回读')
        cancel.clicked.connect(self.cancel_chat)
        buttons.addWidget(cancel)
        layout.addLayout(buttons)
        self.mode.currentIndexChanged.connect(self.chat_mode_changed)
        self.chat_mode_changed(0)
        return tab

    def chat_mode_changed(self,index):
        pending=self.desktop_snapshot and (self.desktop_snapshot['states']['chat']['running'] or self.desktop_snapshot['states']['chat']['pending'])
        if self.chat_busy or self.desktop_request_busy or pending:
            self.mode.blockSignals(True)
            self.mode.setCurrentIndex(self.last_chat_mode)
            self.mode.blockSignals(False)
            self.chat_status.setText('当前请求尚未结束或送达未确认，请先刷新回复。')
            return
        self.last_chat_mode=index
        self.history.clear()
        self.transcript.clear()
        for field in (self.profile,self.base_url,self.protocol,self.model,self.key):field.setEnabled(index==1)
        for field in (self.desktop_threads,self.desktop_refresh,self.desktop_bind,self.desktop_read):field.setEnabled(index==0)
        self.chat_status.setText('ChatGPT 后台管道：请刷新并绑定普通聊天。' if index==0 else '服务商 API：填写地址、模型与凭据。')
        if index==0 and self.desktop_snapshot:self.desktop_state_received(self.desktop_snapshot)

    def desktop_request(self,method,**arguments):
        if self.desktop_request_busy or self.closing:return
        self.desktop_request_busy=True
        self.send_button.setEnabled(False)
        self.chat_status.setText('正在连接客户端后台…')
        def work():
            try:self.desktop.request(method,**arguments)
            except Exception as error:self.events.error.emit('desktop',str(error))
            finally:self.events.chat_done.emit(False)
        threading.Thread(target=work,daemon=True).start()

    def bind_desktop(self):
        target=self.desktop_threads.currentData()
        if not target:
            self.chat_status.setText('请先刷新并选择普通 ChatGPT 会话。')
            return
        self.desktop_request('bind',threadId=target)

    def desktop_state_received(self,snapshot):
        if self.closing:return
        self.desktop_snapshot=snapshot
        selected=self.desktop_threads.currentData()
        self.desktop_threads.blockSignals(True)
        self.desktop_threads.clear()
        for thread in snapshot['threads']:
            if thread['kind']=='chatgpt':self.desktop_threads.addItem(thread['title'],thread['id'])
        state=snapshot['states']['chat']
        choice=self.desktop_threads.findData(selected)
        if choice<0:choice=self.desktop_threads.findData(state['threadId'])
        if choice>=0:self.desktop_threads.setCurrentIndex(choice)
        self.desktop_threads.blockSignals(False)
        if self.mode.currentIndex()!=0:return
        busy=state['running'] or state['pending'] or self.desktop_request_busy
        self.send_button.setEnabled(not busy)
        status=snapshot.get('error') or state.get('error') or state['progress']
        self.chat_status.setText(status+(' · 不会自动重发。' if state['pending'] else ''))
        key=('desktop',state['threadId'])
        replace_text(self.transcript,'绑定会话：'+(state['title'] or '未绑定')+'\n'+state['progress']+'\n\n'+state['output'],
                     preserve=self.transcript_key==key,follow_tail=True)
        self.transcript_key=key

    def desktop_context(self):
        observed=self.observation
        if observed:
            stage=observed.get('stage')
            compact_stage=None
            if stage:
                compact_stage={'name':stage['name'],'confidence':stage['confidence'],'variants':[]}
                for variant in stage['variants']:
                    preview=variant.get('preview') or {}
                    compact_stage['variants'].append({'id':variant['id'],'isElite':variant.get('isElite'),
                        'possible_enemies':[{'name':enemy['name'],'reference_stats':enemy['reference_stats']} for enemy in preview.get('possible_enemies',[])],
                        'notice':'候选敌人；参考属性未应用本局难度及其他修正。'})
            observed={'captured_at':observed.get('captured_at'),'page':observed['page'],
                      'nodes':[{'type':n['type'],'confidence':n['confidence']} for n in observed['nodes']],
                      'stage':compact_stage,'limitations':observed['limitations']}
            observed['map']=(self.observation or {}).get('map')
        return {'observation':observed,'damage':self.damage_result,'run_state':self.run.state,
                'difficulty_preset':self.difficulty.currentData(),'ending_preset':self.ending.currentData()}

    def save_settings(self):
        try:
            profile = self.profile.text().strip()
            if self.key.text():
                save_key(profile,self.key.text())
                self.key.clear()
            data = {'profile':profile,'base_url':self.base_url.text().strip(),
                    'model':self.model.text().strip(),'protocol':self.protocol.currentData()}
            SETTINGS.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
            self.chat_status.setText('配置已保存；密钥由 Windows 凭据管理器保存。')
        except Exception:
            self.chat_status.setText('配置或凭据保存失败。')

    def load_settings(self):
        try:
            data = json.loads(SETTINGS.read_text(encoding='utf-8'))
            self.profile.setText(data.get('profile','default'))
            self.base_url.setText(data.get('base_url','https://api.deepseek.com'))
            self.model.setText(data.get('model',''))
            self.protocol.setCurrentIndex(max(0,self.protocol.findData(data.get('protocol','chat_completions'))))
        except (OSError,ValueError):
            pass

    def send_chat(self):
        from .information_scope import analysis_system_prompt,desktop_analysis_prompt
        if self.chat_busy or self.desktop_request_busy:
            return
        question = self.question.toPlainText().strip()
        if not question:
            return
        if self.mode.currentIndex()==0:
            state=self.desktop_snapshot and self.desktop_snapshot['states']['chat']
            if not state or not state['threadId']:
                self.chat_status.setText('请先刷新、选择并绑定普通 ChatGPT 会话。')
                return
            if state['running'] or state['pending']:
                self.chat_status.setText('已有请求待确认；请刷新回复，不要重复发送。')
                return
            text=desktop_analysis_prompt(question,self.desktop_context() if self.context.isChecked() else None)
            if len(text)>18000:
                self.chat_status.setText('问题和上下文超过 18000 字；请缩短问题或关闭本次上下文。')
                return
            self.desktop_request('send',text=text)
            return
        key = self.key.text() or read_key(self.profile.text().strip())
        if not key:
            self.chat_status.setText('请填写 API Key，或先保存该配置的凭据。')
            return
        config = ProviderConfig(self.base_url.text().strip(),self.model.text().strip(),self.protocol.currentData())
        if not config.model:
            self.chat_status.setText('请填写模型标识。')
            return
        messages = list(self.history)
        state=None
        if self.context.isChecked():
            state = {'observation':self.observation,'damage':self.damage_result,
                     'run_state':self.run.state,
                     'difficulty_preset':self.difficulty.currentData(),'ending_preset':self.ending.currentData()}
        messages.insert(0,{'role':'system','content':analysis_system_prompt(state)})
        messages.append({'role':'user','content':question})
        self.pending_question = question
        self.answer = ''
        self.chat_busy = True
        self.cancel_event = threading.Event()
        cancel_event = self.cancel_event
        self.send_button.setEnabled(False)
        self.transcript.appendPlainText('你：'+question+'\n助手：')
        self.question.clear()
        self.chat_status.setText('正在请求服务商…')
        def work():
            success = False
            try:
                for chunk in stream_chat(config,messages,key,cancel_event):
                    self.events.chunk.emit(chunk)
                success = not cancel_event.is_set()
            except Exception as error:
                self.events.error.emit('chat',str(error))
            finally:
                self.events.chat_done.emit(success)
        threading.Thread(target=work,daemon=True).start()

    def chat_chunk(self, text):
        if self.cancel_event.is_set() or self.closing:
            return
        self.answer += text
        append_text(self.transcript,text)

    def chat_finished(self, success):
        if self.desktop_request_busy:
            self.desktop_request_busy=False
            if self.desktop_snapshot and self.mode.currentIndex()==0:
                state=self.desktop_snapshot['states']['chat']
                self.send_button.setEnabled(not (state['running'] or state['pending']))
            else:self.send_button.setEnabled(True)
            return
        self.chat_busy = False
        self.send_button.setEnabled(True)
        if success and not self.cancel_event.is_set():
            self.history.extend([{'role':'user','content':self.pending_question},{'role':'assistant','content':self.answer}])
            self.chat_status.setText('回答完成。')
        elif self.cancel_event.is_set():
            self.chat_status.setText('已取消本地等待；服务商可能仍在生成，本次未加入聊天上下文。')

    def cancel_chat(self):
        if self.mode.currentIndex()==0:
            self.chat_status.setText('客户端请求仍由后台监测；可在客户端停止对应回复。刷新可确认结果，不会重发。')
            return
        self.cancel_event.set()
        self.chat_status.setText('已取消后续回读；等待当前网络读取结束，服务商可能仍在生成。')

    def clear_chat(self):
        if self.mode.currentIndex()==0:
            self.transcript.clear()
            self.chat_status.setText('仅清空本地显示；客户端会话和待确认发送保持。')
            return
        if self.chat_busy:
            self.chat_status.setText('请等当前请求结束后清空聊天。')
            return
        self.history.clear()
        self.transcript.clear()

    def show_error(self, channel, message):
        if self.closing:
            return
        if channel=='capture':
            self.next_capture_attempt=time.monotonic()+1
            if not self.auto.isChecked():self.capture.set_collecting(False)
            self.recognition_mode.setEnabled(True)
            self.busy=False
            self.sample_button.setEnabled(True)
            self.connect_button.setEnabled(True)
            if self.capture.closed or (self.capture.target and not win32gui.IsWindow(self.capture.target['hwnd'])):
                self.capture.close()
            stamp = time.strftime('%H:%M:%S',time.localtime(self.observation['captured_at'])) if self.observation else '无'
            self.capture_status.setText(message+f' 上次观测时间：{stamp}；未更新。'+(' 自动采样继续监测。' if self.auto.isChecked() else ''))
        else:
            self.chat_status.setText(message)

    def closeEvent(self, event):
        self.closing=True
        self.timer.stop()
        self.cancel_event.set()
        self.capture.close()
        self.desktop.close()
        event.accept()

def main():
    app=QApplication(sys.argv)
    window=MainWindow()
    window.show()
    window.auto.setChecked(True)
    sys.exit(app.exec())

if __name__=='__main__':
    main()
